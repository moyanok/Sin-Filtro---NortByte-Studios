"""Personajes: apariencia, jugador y NPCs (herencia: Personaje -> Jugador / NPC)."""
import math

import pygame

from sin_filtro.config import COLORES_PELO, ESTILOS_PELO, PIELES, ROPAS


class Apariencia:
    def __init__(self, piel, pelo_estilo, pelo_color, contextura, ropa, pantalon=(60, 64, 96), escala=1.0):
        self.piel = piel
        self.pelo_estilo = pelo_estilo
        self.pelo_color = pelo_color
        self.contextura = contextura
        self.ropa = ropa
        self.pantalon = pantalon
        self.escala = escala

    @classmethod
    def desde_ajustes(cls, aj):
        return cls(PIELES[aj.piel], ESTILOS_PELO[aj.pelo_estilo], COLORES_PELO[aj.pelo_color],
                   aj.contextura, ROPAS[aj.ropa])


class Personaje:
    """Entidad que camina por el mundo con animación de pasos."""

    def __init__(self, id_, nombre, apariencia, x=0, y=0, direccion="abajo"):
        self.id = id_
        self.nombre = nombre
        self.ap = apariencia
        self.x, self.y = float(x), float(y)
        self.dir = direccion
        self.caminando = False
        self.t = 0.0

    @property
    def pies(self):
        return pygame.Rect(int(self.x - 11), int(self.y - 8), 22, 10)

    def actualizar(self, dt):
        self.t += dt

    def mover_hacia(self, tx, ty, vel, dt):
        dx, dy = tx - self.x, ty - self.y
        dist = math.hypot(dx, dy)
        if dist < 2:
            self.x, self.y, self.caminando = tx, ty, False
            return True
        paso = min(dist, vel * dt)
        self.x += dx / dist * paso
        self.y += dy / dist * paso
        self.caminando = True
        self.dir = ("der" if dx > 0 else "izq") if abs(dx) > abs(dy) else ("abajo" if dy > 0 else "arriba")
        return False

    def dibujar(self, sup, dibujo):
        dibujo.personaje(sup, self.x, self.y, self.ap, self.dir, self.t, self.caminando)


class Jugador(Personaje):
    VELOCIDAD = 165

    def mover(self, dx, dy, dt, colisiona):
        self.caminando = bool(dx or dy)
        if not self.caminando:
            return
        if dx and dy:
            dx, dy = dx * 0.7071, dy * 0.7071
        self.dir = ("der" if dx > 0 else "izq") if dx and not dy else ("abajo" if dy > 0 else "arriba") if dy else self.dir
        for eje, d in (("x", dx), ("y", dy)):
            if not d:
                continue
            viejo = getattr(self, eje)
            setattr(self, eje, viejo + d * self.VELOCIDAD * dt)
            if colisiona(self.pies):
                setattr(self, eje, viejo)


class NPC(Personaje):
    """Personaje no jugable. Mira hacia Vale cuando ella le habla."""

    def mirar_a(self, otro):
        dx, dy = otro.x - self.x, otro.y - self.y
        self.dir = ("der" if dx > 0 else "izq") if abs(dx) > abs(dy) else ("abajo" if dy > 0 else "arriba")


def crear_reparto(ap_vale):
    """Crea a los personajes secundarios. Mamá y Andrés comparten el tono de piel de Vale (son familia)."""
    return {
        "sofi": NPC("sofi", "Sofi", Apariencia((205, 150, 110), "rizado", (30, 22, 20), 1, (250, 200, 60))),
        "mama": NPC("mama", "Mamá", Apariencia(ap_vale.piel, "moño", (80, 50, 32), 1, (150, 40, 70), (70, 60, 80))),
        "andres": NPC("andres", "Andrés", Apariencia(ap_vale.piel, "corto", ap_vale.pelo_color, 0, (60, 120, 220), escala=0.86)),
        "mateo": NPC("mateo", "Mateo", Apariencia((150, 98, 64), "corto", (25, 20, 18), 1, (60, 170, 110))),
        "laura": NPC("laura", "Laura", Apariencia((250, 220, 195), "largo", (210, 170, 90), 0, (240, 130, 170))),
    }


AP_CAMI = Apariencia((248, 214, 186), "largo", (170, 120, 70), 0, (250, 250, 250))
