"""La historia de Sin Filtro, dividida en capítulos (días) y pasos (objetivos)."""
from sin_filtro.acciones import (Avanzar, ComentariosAleatorios, Decir, Elegir, Emote, Espejo, Esperar, Final,
                                 FinCapitulo, Flag, Flash, Fundido, Glitch, IrA, Llamar, Minijuego, Mirar,
                                 MostrarNPC, Mover, OcultarNPC, Post, Si, Sonido, Stat, Tarjeta)


def V(t, e="normal"):
    return Decir("vale", t, e)


def P(t, e="normal"):
    return Decir("piensa", t, e)


def N(t):
    return Decir("narrador", t)


def A(t):
    return Decir("algo", t)


def D(q, t, e="normal"):
    return Decir(q, t, e)


def noche(valor=True):
    return Llamar(lambda ctx: setattr(ctx, "noche", valor))


def resaltar(valor=True):
    return Llamar(lambda ctx: setattr(ctx, "resaltar_celular", valor))


class Paso:
    def __init__(self, objetivo, mapa, objetivo_id, guion, siguiente=None):
        self.objetivo = objetivo
        self.mapa = mapa
        self.objetivo_id = objetivo_id  # None = se ejecuta solo al llegar a este paso
        self.guion = guion
        self.siguiente = siguiente


class Capitulo:
    numero = 0
    dia = ""
    titulo = ""
    inicio = ("cuarto", "inicio")
    npcs = {}
    pasos = {}
    paso_inicial = ""

    def intro(self):
        return []

    def extras(self, ctx, id_):
        """Diálogos para objetos o personas que no son el objetivo actual."""
        h = ctx.historia
        comunes = {
            "dibujos": [P("Mis dibujos... antes dibujaba todos los días.")],
            "closet": [P("Toda esta ropa y siento que nada me queda bien.")
                       if h["autoestima"] < 50 else P("Este clóset necesita una organizadita.")],
            "cama": [P("Todavía no es hora de dormir.")],
            "celular": [A("¿Me buscabas? Siempre estoy aquí.")] if h["algo"] >= 50 else [P("Mejor no lo abro ahorita.")],
            "espejo": [P("Ahora no quiero mirarme.")],
            "foto_familiar": [P("Esa foto es de cuando fuimos a Santa Marta. Yo tenía 10 y no me importaba nada.")],
            "cocina": [P("Huele a café.")],
            "mesa": [P("La mesa donde casi nunca comemos juntos últimamente.")],
            "sofa": [P("El sofá de las películas de los domingos.")],
            "cartelera": [N("CONCURSO DE BAILE INTERCOLEGIADO. Inscripciones abiertas hasta el viernes.")],
            "arbol": [P("Aquí me sentaba con Sofi en primaria.")],
            "mar": [P("El agua se ve rica.")],
            "castillo": [D("mateo", "No lo toques, todavía está en construcción.")],
            "nevera": [P("Jugos, agua y la torta de Sofi. Prohibido abrirla antes de tiempo.")],
            "mama": [D("mama", "¿Necesitas algo, mi amor?")],
            "andres": [D("andres", "Vale, no me distraigas, estoy viendo un video de rutinas.")],
            "sofi": [D("sofi", "¿Qué más, Vale?", "feliz")],
            "mateo": [D("mateo", "¿Viste el partido de ayer? Bueno, no importa.")],
            "laura": [D("laura", "Tu pelo hoy está lindo, ¿qué te echaste?")],
        }
        return comunes.get(id_, [P("Nada interesante por aquí.")])


# ===================================================================== CAPÍTULO 1
class Capitulo1(Capitulo):
    numero, dia, titulo = 1, "Lunes", "Mil likes"
    npcs = {"sala": [("mama", 190, 220, "abajo"), ("andres", 780, 250, "izq")],
            "colegio": [("sofi", 300, 280, "der"), ("mateo", 560, 330, "izq"), ("laura", 800, 440, "arriba")]}
    paso_inicial = "celular"

    def intro(self):
        return [Tarjeta("Lunes", "Capítulo 1 · Mil likes"), Fundido(False, 1.0), Esperar(0.4),
                Sonido("notificacion", "[vibra el celular]"), Emote("vale", "!"), resaltar(),
                P("Mmm... ¿ya son las 6:30?"), Glitch(0.8),
                A("¡Buenos días, Vale! Soy Algo. Yo decido lo que ves en tu feed."),
                A("Tienes 12 notificaciones nuevas. Y Cami acaba de publicar... la de la vida perfecta, ya sabes."),
                P("¿Ahora el celular me habla? Necesito dormir más."),
                Avanzar("celular")]

    @property
    def pasos(self):
        return {
            "celular": Paso("Revisa tu celular (está en la cama)", "cuarto", "celular", lambda: [
                resaltar(False),
                Post("@cami.perfect", "Lunes de playa. Así me levanto, sin filtro #natural", 48210, "playa_cami"),
                P("¿Cómo hace para verse así un lunes a las seis de la mañana?"),
                A("Si tú te vieras así, también tendrías 48 mil likes. Solo digo."),
                P("..."), Avanzar()], "espejo"),
            "espejo": Paso("Arréglate frente al espejo", "cuarto", "espejo", lambda: [
                Espejo(), P("Bueno... toca irse."), Avanzar()], "desayuno"),
            "desayuno": Paso("Baja a desayunar (puerta de abajo)", "sala", "mama", lambda: [
                D("mama", "¡Por fin bajas! Te hice arepa con huevo, mija. Siéntate un ratico.", "feliz"),
                D("andres", "Ma, si ella no se la come, yo me la como."),
                Elegir("desayuno", [
                    ("Sentarme a desayunar con ellos", [
                        D("mama", "Así me gusta. ¿Y qué, cómo va la semana?", "feliz"),
                        V("Normal, ma. Sofi cumple años el sábado."),
                        D("mama", "¡Ay, qué bueno! Tienes que ir, hace rato no sales."),
                        Stat(mama=8, autoestima=3)]),
                    ("\"Hoy no tengo hambre, ma. Voy tarde\"", [
                        D("mama", "¿Otra vez? Vale, desde hace días casi no desayunas con nosotros...", "triste"),
                        V("Ma, estoy bien. Chao."), Emote("mama", "..."),
                        Stat(mama=-6, autoestima=-4, algo=5), Flag("salto_desayuno")]),
                ]),
                Avanzar()], "sofi"),
            "sofi": Paso("Ve al colegio (puerta derecha) y busca a Sofi", "colegio", "sofi", lambda: [
                D("sofi", "¡Vaaale! Por fin. Te tengo una noticia.", "feliz"),
                D("sofi", "Este sábado celebro mi cumple en la playa. Somos poquitos: tú, Mateo, Laura y yo."),
                D("sofi", "Lleva vestido de baño, ¿oíste? Vamos a pasarla brutal.", "feliz"),
                P("Vestido de baño... con todo el mundo tomando fotos..."),
                Elegir("invitacion", [
                    ("\"¡Obvio voy! No me lo pierdo\"", [
                        D("sofi", "¡Esa es mi amiga!", "feliz"), Emote("sofi", "corazon"),
                        Stat(sofi=8), Flag("acepto_playa")]),
                    ("\"Déjame ver si puedo...\"", [
                        D("sofi", "¿Cómo así? Es mi cumple, Vale...", "triste"), Emote("sofi", "..."),
                        Stat(sofi=-5, algo=5)]),
                ]),
                Avanzar()], "mateo"),
            "mateo": Paso("Saluda a Mateo", "colegio", "mateo", lambda: [
                D("mateo", "Vale, ¿tú fuiste la que hizo el dibujo de la cartelera del año pasado? Está brutal."),
                V("Sí... hace rato no dibujo."),
                D("mateo", "Pues deberías. Y bailar también. En el intercolegiado la rompiste."),
                P("Eso fue antes de verme en los videos."),
                Avanzar()], "noche"),
            "noche": Paso("Vuelve a casa y descansa en tu cuarto (cama)", "cuarto", "cama", lambda: [
                Fundido(True, 0.8), noche(True), N("Esa noche..."), Fundido(False, 0.8),
                Glitch(0.7), A("Vale, Cami subió otra foto. 52 mil likes. Tú no publicas nada hace dos semanas."),
                A("Mira, te armé el editor. Unos ajusticos y listo. Nadie se va a dar cuenta."),
                Minijuego("editor"),
                Si(lambda h: h.resultados.get("editor", {}).get("nivel", 0) > 0.35,
                   [A("¡ESO! Mira esos likes. ¿Ves que sí se puede?"), P("Sí... pero esa no soy yo del todo.", "triste")],
                   [A("Mmm, bueno. Así no vas a llegar muy lejos."), P("A mí me gusta cómo salió. Así soy yo.", "feliz")]),
                Fundido(True, 1.0), FinCapitulo()]),
        }


# ===================================================================== CAPÍTULO 2
class Capitulo2(Capitulo):
    numero, dia, titulo = 2, "Miércoles", "Comentarios"
    npcs = {"sala": [("mama", 260, 210, "abajo"), ("andres", 760, 300, "abajo")],
            "colegio": [("sofi", 380, 300, "izq"), ("mateo", 520, 210, "arriba"), ("laura", 820, 330, "izq")]}
    paso_inicial = "comentarios"

    def intro(self):
        return [noche(False), Tarjeta("Miércoles", "Capítulo 2 · Comentarios"), Fundido(False, 1.0),
                Sonido("notificacion", "[vibra el celular varias veces]"), Emote("vale", "!"), resaltar(),
                P("¿Por qué tantas notificaciones? Ah... la foto."), Avanzar("comentarios")]

    def extras(self, ctx, id_):
        h = ctx.historia
        if id_ == "mama":
            return [D("mama", "Te dejé una arepita en la lonchera, por si te da hambre.")] if h.tiene("salto_desayuno") \
                else [D("mama", "Que te vaya bien, mija. Pórtate juiciosa.", "feliz")]
        if id_ == "andres":
            return [D("andres", "Treinta y uno... treinta y dos... no me hables que pierdo la cuenta.")]
        if id_ == "laura":
            return [D("laura", "Vi tu foto. ¿Qué filtro usaste? Yo uso como tres.")]
        return super().extras(ctx, id_)

    @property
    def pasos(self):
        return {
            "comentarios": Paso("Lee los comentarios de tu foto", "cuarto", "celular", lambda: [
                resaltar(False), Post("@vale.dibuja", "Volviendo de a poquito", 0, "selfie_vale"),
                ComentariosAleatorios(),
                P("Un solo comentario feo y se me olvidan todos los bonitos.", "triste"),
                A("Fácil: borra la foto y sube una más editada."),
                Elegir("comentarios", [
                    ("Borrar la foto", [Stat(autoestima=-5, algo=8), P("Mejor que nadie la vea.", "triste")]),
                    ("Dejarla y silenciar el comentario feo", [
                        Stat(autoestima=5, algo=-6), P("No le voy a dar ese poder a alguien que ni conozco."),
                        Glitch(0.4), A("Hmpf.")]),
                ]),
                Avanzar()], "sofi"),
            "sofi": Paso("Ve al colegio, Sofi te está buscando", "colegio", "sofi", lambda: [
                Si(lambda h: h.resultados.get("editor", {}).get("nivel", 0) > 0.35,
                   [D("sofi", "Vi tu foto. Linda, pero... le metiste editor, ¿cierto?"), V("Un poquito... ¿se nota mucho?")],
                   [D("sofi", "Vi tu foto. ¡Te ves igualita a ti, me encanta!", "feliz"),
                    V("¿En serio? Alguien me comentó que me veía distinta...")]),
                D("sofi", "Mira, en un taller del colegio nos enseñaron algo. Casi todas las fotos de Cami tienen pistas de edición."),
                D("sofi", "Ayúdame a encontrarlas. Vas a ver que la 'perfección' es puro programa."),
                Minijuego("detecta"),
                Si(lambda h: h.resultados.get("detecta", {}).get("encontradas", 0) >= 3,
                   [D("sofi", "¡Eres una detective! ¿Ves? Esa foto no existe en la vida real.", "feliz")],
                   [D("sofi", "Están bien escondidas, ¿no? Por eso uno se cree que son reales.")]),
                D("sofi", "Oye... ¿y tú cómo estás? Te noto rara desde hace días."),
                Elegir("contar_sofi", [
                    ("Contarle cómo me siento de verdad", [
                        V("Siento que nunca me veo bien. Me comparo con todo el mundo y hasta me da pena ir a tu cumple.", "triste"),
                        D("sofi", "Vale... gracias por contarme. A mí también me pasa a veces."),
                        D("sofi", "Vamos a ir juntas, ¿sí? Nadie te va a juzgar. Y si alguien lo hace, se las ve conmigo.", "feliz"),
                        Emote("sofi", "corazon"), Stat(sofi=12, autoestima=8, algo=-5), Flag("conto_sofi")]),
                    ("\"Nada, estoy bien. Solo cansada\"", [
                        D("sofi", "Mmm... bueno. Pero aquí estoy, ¿oíste?"), Stat(sofi=-3, algo=5)]),
                ]),
                Avanzar()], "cartelera"),
            "cartelera": Paso("Mira la cartelera del colegio", "colegio", "cartelera", lambda: [
                N("CONCURSO DE BAILE INTERCOLEGIADO. Inscripciones abiertas hasta el viernes."),
                P("Antes bailaba todos los días... hasta que empecé a verme en los videos."),
                Mover("mateo", 700, 230, 140), D("mateo", "¡Deberías inscribirte! Nadie baila como tú."),
                Elegir("baile_pensar", [
                    ("\"Me lo voy a pensar\"", [Stat(autoestima=3), Flag("pensando_baile"), D("mateo", "¡Eso! Piénsalo.", "feliz")]),
                    ("\"No, ya no bailo\"", [Stat(autoestima=-3), D("mateo", "Qué lástima...")]),
                ]),
                Avanzar()], "noche"),
            "noche": Paso("Vuelve a casa a descansar (cama)", "cuarto", "cama", lambda: [
                Fundido(True, 0.8), noche(True), N("Esa noche, 11:04 p.m."), Fundido(False, 0.8),
                P("Mañana tengo examen de física. Me duermo ya."),
                Sonido("notificacion", "[vibra el celular]"), Glitch(0.6),
                A("¿Dormir? Si apenas son las 11. Mira, un video más... y otro... y otro..."),
                N("Vale abre el celular 'solo un ratico'. Ayúdala a salir del feed y dormirse."),
                Minijuego("scroll"),
                Si(lambda h: h.resultados.get("scroll", {}).get("durmio", False),
                   [P("Uff. Lo logré. Celular a cargar lejos de la cama.", "feliz")],
                   [N("Son las 2:47 a.m. Vale sigue scrolleando."), P("¿En qué momento se me fue la noche?", "triste")]),
                Fundido(True, 1.0), FinCapitulo()]),
        }


# ===================================================================== CAPÍTULO 3
class Capitulo3(Capitulo):
    numero, dia, titulo = 3, "Viernes", "Detrás de Cami"
    npcs = {"sala": [("mama", 480, 220, "abajo"), ("andres", 300, 420, "der")],
            "colegio": [("sofi", 420, 260, "arriba"), ("mateo", 250, 330, "der"), ("laura", 760, 300, "izq")]}
    paso_inicial = "video"

    def intro(self):
        return [noche(False), Tarjeta("Viernes", "Capítulo 3 · Detrás de Cami"), Fundido(False, 1.0),
                Sonido("notificacion", "[vibra el celular]"), resaltar(), Glitch(1.0),
                A("Vale... no abras el video nuevo de Cami. Hazme caso. No te va a gustar."),
                P("¿Y eso? ¿Desde cuándo no quiere que vea algo?"), Avanzar("video")]

    def extras(self, ctx, id_):
        if id_ == "sofi":
            return [D("sofi", "Mañana te paso a buscar a las 9. ¡No te me vas a escapar!", "feliz")]
        if id_ == "laura":
            return [D("laura", "¿Viste el video de Cami? Me dejó pensando...")]
        return super().extras(ctx, id_)

    @property
    def pasos(self):
        return {
            "video": Paso("Mira el video nuevo de Cami", "cuarto", "celular", lambda: [
                resaltar(False), Post("@cami.perfect", "Hoy no hay filtro. Tengo que contarles algo.", 61530, "video_cami"),
                D("cami", "Llevo dos años editando cada foto que subo. La cintura, la piel, todo.", "triste"),
                D("cami", "Dejé de ir a la playa con mis amigas porque no me veía como en mis fotos. Ni yo me reconozco.", "triste"),
                D("cami", "Si me sigues porque querías ser como yo... esa 'yo' no existe. Cuídense, en serio."),
                Glitch(0.9), A("¡Bah! Seguro lo hace por likes. Mañana vuelve con fotos perfectas, ya verás."),
                P("O sea que... ¿hasta ella se siente así?", "sorpresa"),
                Elegir("dejar_seguir", [
                    ("Dejar de seguir cuentas que me hacen sentir mal", [
                        Stat(algo=-15, autoestima=6), Glitch(1.0),
                        A("¡Oye! ¿Qué haces? ¡Me estás quitando poder!"), Flag("limpio_feed"),
                        P("Mi feed, mis reglas.", "feliz")]),
                    ("Seguir todo igual, es solo un video", [
                        Stat(algo=8), A("Así me gusta. Tú tranquila, yo me encargo.")]),
                ]),
                Avanzar()], "mama"),
            "mama": Paso("Baja a la sala, tu mamá te llama", "sala", "mama", lambda: [
                D("mama", "Vale, ven un momentico. Siéntate conmigo."),
                D("mama", "Te noto distinta. Casi no comes con nosotros, no sales, vives pegada al celular... ¿qué está pasando, mi amor?", "triste"),
                Elegir("hablar_mama", [
                    ("Contarle la verdad", [
                        V("Ma... siento que nunca me veo bien. Veo a las de Instagram y me siento horrible.", "triste"),
                        V("Hasta me da miedo ir a la playa mañana.", "triste"),
                        Esperar(0.5), Emote("mama", "corazon"),
                        D("mama", "Ay, mi niña... ¿por qué no me habías dicho?"),
                        D("mama", "Cuando yo tenía tu edad eran las revistas. Me pasé años sintiéndome así y nunca se lo conté a nadie."),
                        D("mama", "No te voy a dejar sola con esto. Si quieres, hablamos con la psicóloga del colegio. Pedir ayuda no es de débiles.", "feliz"),
                        Stat(mama=15, autoestima=10, algo=-8), Flag("hablo_mama")]),
                    ("\"Nada, ma. Son cosas tuyas\"", [
                        D("mama", "Bueno... cuando quieras hablar, aquí estoy.", "triste"), Emote("mama", "..."),
                        Stat(mama=-8, algo=6)]),
                ]),
                Avanzar()], "andres"),
            "andres": Paso("Habla con Andrés", "sala", "andres", lambda: [
                D("andres", "Vale, ¿tú crees que si hago 100 flexiones diarias quedo como los del gym de TikTok?"),
                D("andres", "Es que en el salón todos suben fotos sin camisa y yo parezco un fideo.", "triste"),
                P("Wow... a él también le pasa.", "sorpresa"),
                Elegir("consejo_andres", [
                    ("Contarle lo que aprendí de los filtros", [
                        V("Andrés, la mitad de esos videos son editados o puro ángulo. Haz ejercicio porque te gusta, no para parecerte a nadie."),
                        D("andres", "Mmm... ok. Igual lo que me gusta es el fútbol. Me voy a jugar con los pelaos.", "feliz"),
                        Stat(autoestima=6), Flag("ayudo_andres")]),
                    ("\"Hazle, dale duro\"", [
                        D("andres", "¡Listo! Ciento uno, ciento dos..."), P("Mmm... no sé si eso estuvo bien."),
                        Stat(autoestima=-2)]),
                ]),
                Avanzar()], "inscripcion"),
            "inscripcion": Paso("Último día: ve a la cartelera del concurso de baile", "colegio", "cartelera", lambda: [
                Si(lambda h: h.tiene("pensando_baile"), [P("Me lo estuve pensando toda la semana...")]),
                Elegir("inscripcion", [
                    ("Inscribirme al concurso", [
                        N("Vale escribe su nombre en la lista. Le tiembla un poquito la mano."),
                        Sonido("logro", "[sonido de logro]"), Stat(autoestima=10, algo=-5), Flag("inscrita_baile"),
                        Mover("sofi", 700, 230, 160), D("sofi", "¡¿TE INSCRIBISTE?! Te voy a gritar desde primera fila.", "feliz")]),
                    ("Mejor no", [P("¿Y si me graban y lo suben? No, qué pena."), Stat(autoestima=-4)]),
                ]),
                Avanzar()], "espejo"),
            "espejo": Paso("Antes de dormir, mírate al espejo", "cuarto", "espejo", lambda: [
                noche(True), Espejo(), P("Mañana es el cumple de Sofi..."), Fundido(True, 1.0), FinCapitulo()]),
        }


# ===================================================================== CAPÍTULO 4
class Capitulo4(Capitulo):
    numero, dia, titulo = 4, "Sábado", "La playa"
    npcs = {"sala": [("andres", 760, 160, "abajo")],
            "playa": [("sofi", 420, 300, "abajo"), ("mateo", 690, 400, "arriba"), ("laura", 640, 260, "izq")]}
    paso_inicial = "vestido"

    def intro(self):
        return [noche(False), Tarjeta("Sábado", "Capítulo 4 · La playa"), Fundido(False, 1.0),
                P("Hoy es el cumple de Sofi."), Avanzar("vestido")]

    def extras(self, ctx, id_):
        if id_ == "laura":
            return [D("laura", "¡Viniste! Sofi estaba nerviosa de que no vinieras.", "feliz")]
        if id_ == "nevera":
            return [D("sofi", "¡Esa torta es para después! Fuera, fuera.", "feliz")]
        return super().extras(ctx, id_)

    def _final_playa(self):
        return [
            D("sofi", "¡Foto grupal! Todos aquí. Uno, dos, tres... ¡Whisky!", "feliz"),
            Mover("mateo", 470, 300, 160), Mover("laura", 520, 300, 160), Flash(), Esperar(0.4),
            D("sofi", "Quedó brutal. Te la paso, ¿la subes tú?", "feliz"),
            Si(lambda h: h["algo"] > 40, [Glitch(0.8), A("Última oportunidad. Un poquito de editor y quedas perfecta.")]),
            Elegir("foto_final", [
                ("Subirla tal cual, así fue el día", [
                    Flag("publico_real"), Stat(autoestima=10, algo=-15),
                    Post("@vale.dibuja", "El mejor cumple. Sin filtro, de verdad.", 312, "grupo"),
                    P("No es la foto perfecta. Es la foto de un día perfecto.", "feliz")]),
                ("Editarme un poquito antes", [Stat(autoestima=-6, algo=10), P("Bueno... solo un poquito.")]),
                ("No subir nada y seguir disfrutando", [
                    Stat(autoestima=6, algo=-10), N("Vale guarda el celular en el bolso y corre al agua con Sofi.")]),
            ]),
            Fundido(True, 1.2), Final()]

    @property
    def pasos(self):
        return {
            "vestido": Paso("Alístate: el vestido de baño está en la cama", "cuarto", "vestido", lambda: [
                P("Ahí está. Lo compré hace un año y nunca lo he usado."), Glitch(1.0),
                A("Vale, piénsalo bien. Mateo y Laura van a tomar fotos. Fotos que se quedan en internet. Para siempre."),
                A("Mejor quédate. Yo te pongo videos toda la tarde. Es más fácil."),
                Si(lambda h: h["autoestima"] >= 50 or h.tiene("conto_sofi"),
                   [P("Sofi me dijo que íbamos juntas...")], [P("¿Y si tiene razón?", "triste")]),
                Elegir("ir_playa", [
                    ("Ir a la playa con Sofi", [
                        Flag("fue_playa"), Stat(autoestima=6, algo=-10), Glitch(0.6), A("¡No! Espera, Vale..."),
                        V("Chao, Algo.", "feliz"), Fundido(True, 0.8), N("Una hora después..."),
                        IrA("playa", "llegada"), Fundido(False, 1.0), Avanzar("saludo")]),
                    ("Quedarme en casa", [Stat(autoestima=-8, algo=10, sofi=-10), Avanzar("casa")]),
                ])]),
            "saludo": Paso("Saluda a Sofi en la playa", "playa", "sofi", lambda: [
                D("sofi", "¡VINISTE! Ay, no sabes lo feliz que me haces.", "feliz"), Emote("sofi", "corazon"),
                Stat(sofi=10), D("sofi", "Ve y métete al agua, que está deliciosa. Ahorita te alcanzo."),
                Avanzar()], "mar"),
            "mar": Paso("Métete al mar", "playa", "mar", lambda: [
                Sonido("bien", "[olas]"), P("El agua está deliciosa...", "feliz"),
                N("Por un rato, Vale se olvida del celular, de Algo y de cómo se ve."),
                Emote("vale", "corazon"), Stat(autoestima=6), Avanzar()], "castillo"),
            "castillo": Paso("Ayuda con el castillo de arena (habla con Mateo)", "playa", "mateo", lambda: [
                D("mateo", "Laura dice que parece una arepa derretida. Yo digo que es arte moderno."),
                D("laura", "Vale, ¿nos bailas algo para el video del cumple de Sofi?", "feliz"),
                Si(lambda h: h.tiene("inscrita_baile"),
                   [V("¡Dale! Así practico para el concurso.", "feliz"),
                    N("Vale baila en la orilla. Nadie mira cómo se ve; todos miran cómo se divierte."),
                    Emote("sofi", "corazon"), Emote("mateo", "!"), Stat(autoestima=8)],
                   [V("Jaja, otro día..."), D("laura", "Bueno, pero me debes una.")]),
                Avanzar()], "foto"),
            "foto": Paso("Sofi quiere la foto del cumpleaños", "playa", "sofi", self._final_playa),
            "casa": Paso("", "cuarto", None, lambda: [
                Fundido(True, 0.8), N("Vale se queda en su cuarto. Pasan las horas."), Fundido(False, 0.8),
                Glitch(0.8), A("¿Ves? Aquí estás segura. Mira, Sofi subió historias. Todos se ven felices."),
                Post("@sofi.rizos", "Faltó alguien importante hoy :(", 340, "grupo_sin_vale"),
                P("Me estoy perdiendo el cumple de mi mejor amiga... por miedo a una foto.", "triste"),
                Si(lambda h: h["mama"] >= 55 or h.tiene("hablo_mama"), [
                    Sonido("puerta", "[tocan la puerta]"), N("Tocan la puerta."),
                    MostrarNPC("mama", "cuarto", 480, 500, "arriba"), Mover("mama", 420, 360, 110),
                    D("mama", "Mi amor, todavía estás a tiempo. Yo te llevo. Y si quieres, me quedo cerca."),
                    Elegir("segunda_oportunidad", [
                        ("Ir al atardecer con mamá", [
                            Flag("fue_playa"), Flag("fue_tarde"), Stat(autoestima=8, algo=-10, mama=5),
                            Fundido(True, 0.8), OcultarNPC("mama", "cuarto"),
                            Llamar(lambda ctx: setattr(ctx, "atardecer", True)),
                            IrA("playa", "llegada"), Fundido(False, 1.0),
                            D("sofi", "¡LLEGASTE! Justo para el atardecer.", "feliz"), Emote("sofi", "corazon"),
                            N("No hubo fotos perfectas. Hubo un atardecer, una torta y su mejor amiga."),
                            Fundido(True, 1.2), Final()]),
                        ("Quedarme", [D("mama", "Está bien. Aquí estoy si me necesitas.", "triste"), Fundido(True, 1.2), Final()]),
                    ])],
                   [N("Nadie toca la puerta. Solo vibra el celular."), Fundido(True, 1.2), Final()])]),
        }


CAPITULOS = [Capitulo1, Capitulo2, Capitulo3, Capitulo4]
