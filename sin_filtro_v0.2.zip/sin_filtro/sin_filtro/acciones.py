"""Acciones de las cinemáticas (patrón Command). Cada acción sabe iniciarse, actualizarse,
recibir teclas y dibujarse. El Guion las ejecuta en orden."""
import random
from abc import ABC

import pygame

from sin_filtro import eventos as ev
from sin_filtro.config import ALTO, ANCHO
from sin_filtro.personajes import AP_CAMI

CONFIRMAR = (pygame.K_e, pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER)

NOMBRES = {"vale": "Vale", "piensa": "Vale (piensa)", "algo": "Algo", "cami": "Cami", "sofi": "Sofi",
           "mama": "Mamá", "andres": "Andrés", "mateo": "Mateo", "laura": "Laura", "narrador": ""}


def es_confirmar(e):
    return (e.type == pygame.KEYDOWN and e.key in CONFIRMAR) or (e.type == pygame.MOUSEBUTTONDOWN and e.button == 1)


class Accion(ABC):
    def iniciar(self, ctx):
        pass

    def actualizar(self, ctx, dt):
        return True

    def manejar_evento(self, ctx, e):
        pass

    def dibujar(self, ctx, sup):
        pass


# ------------------------------------------------------------------ diálogo
class Decir(Accion):
    def __init__(self, quien, texto, expresion="normal", nombre=None):
        self.quien, self.texto, self.expresion, self.nombre = quien, texto, expresion, nombre

    def iniciar(self, ctx):
        self.mostrado = 0.0
        self.listo = False
        self.t = 0.0
        self._blip = 0
        if self.quien == "algo":
            ctx.glitch = max(ctx.glitch, 0.25)
        hablante = ctx.personaje(self.quien)
        if hablante is not None and self.quien not in ("vale", "piensa"):
            hablante.mirar_a(ctx.jugador) if hasattr(hablante, "mirar_a") else None

    def actualizar(self, ctx, dt):
        self.t += dt
        antes = int(self.mostrado)
        self.mostrado = min(len(self.texto), self.mostrado + ctx.juego.ajustes.cps * dt)
        if int(self.mostrado) // 3 > antes // 3 and self.quien != "narrador":
            ctx.bus.publicar(ev.SONIDO, nombre="blip")
        return self.listo

    def manejar_evento(self, ctx, e):
        if es_confirmar(e) and self.t > 0.12:
            if self.mostrado < len(self.texto):
                self.mostrado = len(self.texto)
            else:
                self.listo = True

    def dibujar(self, ctx, sup):
        d, pal = ctx.dibujo, ctx.paleta
        caja = pygame.Rect(20, ALTO - 158, ANCHO - 40, 140)
        jit = random.randint(-2, 2) if self.quien == "algo" and random.random() < 0.3 else 0
        caja.x += jit
        borde = pal["algo"] if self.quien == "algo" else pal["borde"]
        d.panel(sup, caja, pal, borde)
        x_texto = caja.x + 24
        if self.quien not in ("narrador", "comentario"):
            ap = self._apariencia(ctx)
            ret = pygame.Rect(caja.x + 14, caja.y + 12, 116, 116)
            exp = self.expresion
            d.retrato(sup, ret, self.quien, ap, self.t, exp, pal)
            x_texto = ret.right + 20
        nombre = self.nombre or NOMBRES.get(self.quien, self.quien.title())
        if nombre:
            etiqueta = pygame.Rect(x_texto - 6, caja.y - 22, d.f["normal"].size(nombre)[0] + 24, 34)
            pygame.draw.rect(sup, borde, etiqueta, border_radius=10)
            d.texto(sup, nombre, etiqueta.center, pal["panel"], "normal", "center")
        visible = self.texto[: int(self.mostrado)]
        fuente = d.cursiva if self.quien in ("piensa", "narrador") else d.f["normal"]
        color = pal["suave"] if self.quien == "piensa" else pal["texto"]
        if self.quien == "narrador":
            d.parrafo(sup, visible, caja.x + 40, caja.y + 30, caja.w - 80, color, fuente, centrado=True)
        else:
            d.parrafo(sup, visible, x_texto, caja.y + 22, caja.right - x_texto - 24, color, fuente)
        if self.mostrado >= len(self.texto) and int(self.t * 2.5) % 2 == 0:
            d.texto(sup, "E / Espacio  >", (caja.right - 16, caja.bottom - 10), pal["acento"], "mini", "bottomright")

    def _apariencia(self, ctx):
        if self.quien in ("vale", "piensa"):
            return ctx.jugador.ap
        if self.quien == "cami":
            return AP_CAMI
        p = ctx.reparto.get(self.quien)
        return p.ap if p else None


class Elegir(Accion):
    """Decisión dentro de la historia. Cada opción es una acción (no una respuesta correcta/incorrecta)."""

    def __init__(self, id_, opciones):
        self.id = id_
        self.opciones = opciones  # [(texto, [acciones])]

    def iniciar(self, ctx):
        self.sel = 0
        self.listo = False
        self.t = 0.0

    def _rects(self):
        n = len(self.opciones)
        alto = 50
        y0 = ALTO - 30 - n * (alto + 10)
        return [pygame.Rect(150, y0 + i * (alto + 10), ANCHO - 300, alto) for i in range(n)]

    def actualizar(self, ctx, dt):
        self.t += dt
        return self.listo

    def _elegir(self, ctx, i):
        texto, acciones = self.opciones[i]
        ctx.historia.registrar_decision(self.id, texto)
        ctx.bus.publicar(ev.SONIDO, nombre="elegir")
        ctx.guion.insertar(acciones)
        self.listo = True

    def manejar_evento(self, ctx, e):
        if self.t < 0.2 or self.listo:
            return
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_w, pygame.K_UP):
                self.sel = (self.sel - 1) % len(self.opciones)
                ctx.bus.publicar(ev.SONIDO, nombre="mover")
            elif e.key in (pygame.K_s, pygame.K_DOWN):
                self.sel = (self.sel + 1) % len(self.opciones)
                ctx.bus.publicar(ev.SONIDO, nombre="mover")
            elif e.key in CONFIRMAR:
                self._elegir(ctx, self.sel)
            elif pygame.K_1 <= e.key <= pygame.K_9 and e.key - pygame.K_1 < len(self.opciones):
                self._elegir(ctx, e.key - pygame.K_1)
        elif e.type == pygame.MOUSEMOTION:
            for i, r in enumerate(self._rects()):
                if r.collidepoint(e.pos):
                    self.sel = i
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i, r in enumerate(self._rects()):
                if r.collidepoint(e.pos):
                    self._elegir(ctx, i)

    def dibujar(self, ctx, sup):
        d, pal = ctx.dibujo, ctx.paleta
        rects = self._rects()
        cab = pygame.Rect(0, 0, 220, 36)
        cab.midbottom = (ANCHO // 2, rects[0].y - 6)
        d.panel(sup, cab, pal, pal["acento"], 10, 245)
        d.texto(sup, "¿Qué hace Vale?", cab.center, pal["acento"], "normal", "center")
        for i, (r, (texto, _)) in enumerate(zip(rects, self.opciones)):
            sel = i == self.sel
            d.panel(sup, r, pal, pal["acento"] if sel else pal["borde"], 12, 245)
            if sel:
                pygame.draw.rect(sup, pal["sel"], r.inflate(-6, -6), border_radius=10)
            d.texto(sup, f"{i + 1}.  {texto}", (r.x + 20, r.centery), pal["texto"], "normal", "midleft")


# ------------------------------------------------------------------ lógica
class Stat(Accion):
    def __init__(self, **deltas):
        self.deltas = deltas

    def iniciar(self, ctx):
        ctx.historia.cambiar(**self.deltas)


class Flag(Accion):
    def __init__(self, nombre):
        self.nombre = nombre

    def iniciar(self, ctx):
        ctx.historia.poner(self.nombre)


class Si(Accion):
    def __init__(self, condicion, si, no=()):
        self.condicion, self.si, self.no = condicion, list(si), list(no)

    def iniciar(self, ctx):
        ctx.guion.insertar(self.si if self.condicion(ctx.historia) else self.no)


class Llamar(Accion):
    def __init__(self, funcion):
        self.funcion = funcion

    def iniciar(self, ctx):
        self.funcion(ctx)


class Sonido(Accion):
    def __init__(self, nombre, subtitulo=None):
        self.nombre, self.subtitulo = nombre, subtitulo

    def iniciar(self, ctx):
        ctx.bus.publicar(ev.SONIDO, nombre=self.nombre, subtitulo=self.subtitulo)


class Avanzar(Accion):
    def __init__(self, destino=None):
        self.destino = destino

    def iniciar(self, ctx):
        ctx.avanzar_paso(self.destino)


class FinCapitulo(Accion):
    def iniciar(self, ctx):
        ctx.siguiente_capitulo()


class Final(Accion):
    def iniciar(self, ctx):
        ctx.terminar_historia()


# ------------------------------------------------------------------ animación
class Esperar(Accion):
    def __init__(self, seg):
        self.seg = seg

    def iniciar(self, ctx):
        self.t = 0

    def actualizar(self, ctx, dt):
        self.t += dt
        return self.t >= self.seg


class Mover(Accion):
    def __init__(self, quien, x, y, vel=120):
        self.quien, self.x, self.y, self.vel = quien, x, y, vel

    def actualizar(self, ctx, dt):
        p = ctx.personaje(self.quien)
        return p is None or p.mover_hacia(self.x, self.y, self.vel, dt)


class Mirar(Accion):
    def __init__(self, quien, direccion):
        self.quien, self.direccion = quien, direccion

    def iniciar(self, ctx):
        p = ctx.personaje(self.quien)
        if p:
            p.dir = self.direccion


class Fundido(Accion):
    def __init__(self, a_negro=True, dur=0.6):
        self.a_negro, self.dur = a_negro, dur

    def iniciar(self, ctx):
        self.desde = ctx.fade
        self.hasta = 255 if self.a_negro else 0
        self.t = 0

    def actualizar(self, ctx, dt):
        self.t += dt
        k = min(1, self.t / self.dur)
        ctx.fade = self.desde + (self.hasta - self.desde) * k
        return k >= 1


class IrA(Accion):
    def __init__(self, mapa, spawn):
        self.mapa, self.spawn = mapa, spawn

    def iniciar(self, ctx):
        ctx.ir_a(self.mapa, self.spawn)


class Glitch(Accion):
    def __init__(self, dur=0.6):
        self.dur = dur

    def iniciar(self, ctx):
        ctx.glitch = self.dur
        ctx.bus.publicar(ev.SONIDO, nombre="glitch", subtitulo="[interferencia digital]")


class Flash(Accion):
    def iniciar(self, ctx):
        ctx.flash = 0.5
        ctx.bus.publicar(ev.SONIDO, nombre="foto", subtitulo="[clic de cámara]")


class Emote(Accion):
    def __init__(self, quien, tipo):
        self.quien, self.tipo = quien, tipo

    def iniciar(self, ctx):
        ctx.emotes.append([self.quien, self.tipo, 0.0])


class MostrarNPC(Accion):
    def __init__(self, id_, mapa, x, y, direccion="abajo"):
        self.args = (id_, mapa, x, y, direccion)

    def iniciar(self, ctx):
        ctx.colocar_npc(*self.args)


class OcultarNPC(Accion):
    def __init__(self, id_, mapa):
        self.id, self.mapa = id_, mapa

    def iniciar(self, ctx):
        ctx.quitar_npc(self.id, self.mapa)


class Tarjeta(Accion):
    def __init__(self, dia, titulo, momento="mañana"):
        self.dia, self.titulo, self.momento = dia, titulo, momento

    def iniciar(self, ctx):
        from sin_filtro.estados.escenas import EstadoTarjeta
        self.listo = False
        ctx.juego.apilar(EstadoTarjeta(ctx.juego, self.dia, self.titulo, self.momento, self._fin))

    def _fin(self):
        self.listo = True

    def actualizar(self, ctx, dt):
        return self.listo


class Espejo(Accion):
    def iniciar(self, ctx):
        from sin_filtro.estados.escenas import EstadoEspejo
        self.listo = False
        ctx.juego.apilar(EstadoEspejo(ctx.juego, ctx.historia, ctx.jugador.ap, self._fin))

    def _fin(self):
        self.listo = True

    def actualizar(self, ctx, dt):
        return self.listo


class Minijuego(Accion):
    def __init__(self, nombre):
        self.nombre = nombre

    def iniciar(self, ctx):
        from sin_filtro.minijuegos import crear_minijuego
        self.listo = False
        ctx.juego.apilar(crear_minijuego(self.nombre, ctx.juego, ctx.historia, ctx.jugador.ap, self._fin))

    def _fin(self, _resultado):
        self.listo = True

    def actualizar(self, ctx, dt):
        return self.listo


class Post(Accion):
    """Escena animada: el celular entra a la pantalla y muestra una publicación con likes contando."""

    def __init__(self, autor, texto, likes, escena):
        self.autor, self.texto, self.likes, self.escena = autor, texto, likes, escena

    def iniciar(self, ctx):
        self.t = 0.0
        self.saliendo = None
        ctx.bus.publicar(ev.SONIDO, nombre="notificacion", subtitulo="[vibra el celular]")

    def actualizar(self, ctx, dt):
        self.t += dt
        if self.saliendo is not None:
            self.saliendo += dt
            return self.saliendo >= 0.3
        return False

    def manejar_evento(self, ctx, e):
        if es_confirmar(e) and self.t > 0.8 and self.saliendo is None:
            self.saliendo = 0.0

    def dibujar(self, ctx, sup):
        d, pal = ctx.dibujo, ctx.paleta
        velo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        velo.fill((0, 0, 0, 150))
        sup.blit(velo, (0, 0))
        entrada = min(1, self.t / 0.35)
        salida = 0 if self.saliendo is None else min(1, self.saliendo / 0.3)
        y_off = int((1 - entrada) * 500 + salida * 500)
        tel = pygame.Rect(0, 0, 320, 500)
        tel.center = (ANCHO // 2, ALTO // 2 + 10 + y_off)
        pygame.draw.rect(sup, (20, 20, 28), tel, border_radius=30)
        pant = tel.inflate(-20, -24)
        pygame.draw.rect(sup, (250, 250, 252), pant, border_radius=22)
        pygame.draw.circle(sup, (200, 120, 200), (pant.x + 26, pant.y + 28), 14)
        d.texto(sup, self.autor, (pant.x + 48, pant.y + 18), (30, 30, 40), "peq")
        img = pygame.Rect(pant.x + 10, pant.y + 50, pant.w - 20, 250)
        dibujar_escena_post(sup, img, self.escena, ctx, self.t)
        likes = int(self.likes * min(1, self.t / 1.4))
        d.corazon(sup, pant.x + 26, img.bottom + 22, 10, (235, 70, 110))
        d.texto(sup, f"{likes:,} me gusta".replace(",", "."), (pant.x + 44, img.bottom + 12), (30, 30, 40), "peq")
        d.parrafo(sup, self.texto, pant.x + 14, img.bottom + 42, pant.w - 28, (50, 50, 60), "peq", 2)
        if self.t > 0.8 and int(self.t * 2.5) % 2 == 0:
            d.texto(sup, "E / Espacio >", (tel.centerx, tel.bottom + 12), (255, 255, 255), "mini", "midtop")


def dibujar_escena_post(sup, r, escena, ctx, t):
    """Imágenes de las publicaciones, dibujadas en código."""
    d = ctx.dibujo
    clip = sup.get_clip()
    sup.set_clip(r)
    if escena in ("playa_cami", "grupo", "grupo_sin_vale", "selfie_vale"):
        sup.fill((150, 210, 245), r)
        sup.fill((60, 150, 210), (r.x, r.y + 90, r.w, 60))
        sup.fill((240, 220, 160), (r.x, r.y + 150, r.w, r.h - 150))
        pygame.draw.circle(sup, (255, 230, 120), (r.right - 40, r.y + 40), 22)
        if escena == "playa_cami":
            d.personaje(sup, r.centerx, r.bottom - 8, AP_CAMI, "abajo", t, False, 2.6, "feliz")
            brillo = pygame.Surface(r.size, pygame.SRCALPHA)
            brillo.fill((255, 200, 220, 50))
            sup.blit(brillo, r.topleft)
        elif escena == "selfie_vale":
            d.personaje(sup, r.centerx, r.bottom - 8, ctx.jugador.ap, "abajo", t, False, 2.6, "feliz")
            nivel = ctx.historia.resultados.get("editor", {}).get("nivel", 0)
            if nivel > 0.05:
                brillo = pygame.Surface(r.size, pygame.SRCALPHA)
                brillo.fill((255, 190, 210, int(90 * nivel)))
                sup.blit(brillo, r.topleft)
        else:
            gente = [ctx.reparto["sofi"].ap, ctx.reparto["mateo"].ap, ctx.reparto["laura"].ap]
            if escena == "grupo":
                gente.insert(1, ctx.jugador.ap)
            paso = r.w // (len(gente) + 1)
            for i, ap in enumerate(gente):
                d.personaje(sup, r.x + paso * (i + 1), r.bottom - 10, ap, "abajo", t, False, 1.6, "feliz")
    elif escena == "video_cami":
        sup.fill((60, 55, 70), r)
        d.personaje(sup, r.centerx, r.bottom + 150, AP_CAMI, "abajo", t, False, 4.2, "triste")
        pygame.draw.rect(sup, (220, 40, 60), (r.x + 10, r.y + 10, 52, 22), border_radius=4)
        d.texto(sup, "VIDEO", (r.x + 36, r.y + 21), (255, 255, 255), "mini", "center")
        d.texto(sup, "sin filtro", (r.right - 10, r.y + 12), (230, 230, 230), "mini", "topright")
    sup.set_clip(clip)
    pygame.draw.rect(sup, (220, 220, 225), r, 1)


class ComentariosAleatorios(Accion):
    """Factory de comentarios: elige al azar qué le comentan a Vale (componente aleatorio)."""

    BUENOS = ["Qué linda, te extrañábamos por aquí", "Esa foto está brutal", "Te ves feliz, me encanta",
              "Reina, ¿qué playa es esa?"]
    MALOS = ["¿Esa eres tú? En persona te ves distinta jaja", "Mucho filtro, ¿no?",
             "Cami lo hace mejor", "Mmm... ¿segura que subes eso?"]
    USUARIOS = ["@lau.ra", "@mateo_10", "@x_anonimo_x", "@dani.fit", "@sofi.rizos", "@tia_marlene"]

    def iniciar(self, ctx):
        rng = ctx.rng
        editada = ctx.historia.resultados.get("editor", {}).get("nivel", 0) > 0.35
        malos = 2 if editada else 1
        lineas = [(rng.choice(self.BUENOS), "bien") for _ in range(3 - malos)] + \
                 [(m, "mal") for m in rng.sample(self.MALOS, malos)]
        rng.shuffle(lineas)
        usuarios = rng.sample(self.USUARIOS, len(lineas))
        ctx.guion.insertar([Decir("comentario", txt, nombre=u) for (txt, _), u in zip(lineas, usuarios)])
