"""Lugares del juego. Cada mapa define sus obstáculos, objetos interactivos y puertas."""
import math
from abc import ABC, abstractmethod

import pygame

from sin_filtro.config import ALTO, ANCHO, HUD


class ObjetoInteractivo:
    def __init__(self, id_, nombre, rect, visible_si=None, prioridad=0):
        self.id = id_
        self.nombre = nombre
        self.rect = pygame.Rect(rect)
        self._visible_si = visible_si
        self.prioridad = prioridad  # penalización: los objetos grandes ceden ante los pequeños cercanos

    def visible(self, historia):
        return self._visible_si is None or self._visible_si(historia)


class Puerta:
    def __init__(self, rect, destino, spawn, etiqueta):
        self.rect = pygame.Rect(rect)
        self.destino = destino
        self.spawn = spawn
        self.etiqueta = etiqueta


class Mapa(ABC):
    id = ""
    nombre = ""

    def __init__(self):
        self.solidos = []
        self.objetos = {}
        self.puertas = []
        self.spawns = {}
        self.construir()

    @abstractmethod
    def construir(self): ...

    @abstractmethod
    def dibujar_fondo(self, sup, t, ctx): ...

    def dibujar_frente(self, sup, t, ctx):
        pass

    def agregar_objeto(self, obj, solido=False):
        self.objetos[obj.id] = obj
        if solido:
            self.solidos.append(obj.rect)

    def paredes(self, puerta_abajo=None, puerta_arriba=None, puerta_izq=None, puerta_der=None, alto_pared=84):
        """Paredes del borde con huecos para las puertas (x0, x1) o (y0, y1)."""
        top = HUD + alto_pared
        if puerta_arriba:
            a, b = puerta_arriba
            self.solidos += [pygame.Rect(0, HUD, a, alto_pared), pygame.Rect(b, HUD, ANCHO - b, alto_pared),
                             pygame.Rect(a, HUD, b - a, alto_pared - 18)]
        else:
            self.solidos.append(pygame.Rect(0, HUD, ANCHO, alto_pared))
        if puerta_abajo:
            a, b = puerta_abajo
            self.solidos += [pygame.Rect(0, ALTO - 18, a, 18), pygame.Rect(b, ALTO - 18, ANCHO - b, 18)]
        else:
            self.solidos.append(pygame.Rect(0, ALTO - 18, ANCHO, 18))
        for lado, puerta in (("izq", puerta_izq), ("der", puerta_der)):
            x = 0 if lado == "izq" else ANCHO - 18
            if puerta:
                a, b = puerta
                self.solidos += [pygame.Rect(x, HUD, 18, a - HUD), pygame.Rect(x, b, 18, ALTO - b)]
            else:
                self.solidos.append(pygame.Rect(x, HUD, 18, ALTO - HUD))
        return top

    @staticmethod
    def piso(sup, top, c1, c2, tam=48):
        for j, y in enumerate(range(top, ALTO, tam)):
            for i, x in enumerate(range(0, ANCHO, tam)):
                pygame.draw.rect(sup, c1 if (i + j) % 2 else c2, (x, y, tam, tam))


# ------------------------------------------------------------------ CUARTO
class Cuarto(Mapa):
    id, nombre = "cuarto", "Cuarto de Vale"

    def construir(self):
        self.top = self.paredes(puerta_abajo=(440, 520))
        self.agregar_objeto(ObjetoInteractivo("cama", "Cama", (40, 130, 190, 130), prioridad=25), True)
        self.agregar_objeto(ObjetoInteractivo("celular", "Celular", (238, 136, 44, 40)), True)
        self.agregar_objeto(ObjetoInteractivo("dibujos", "Dibujos", (380, 120, 180, 60)), True)
        self.agregar_objeto(ObjetoInteractivo("closet", "Clóset", (620, 110, 120, 92)), True)
        self.agregar_objeto(ObjetoInteractivo("espejo", "Espejo", (830, 118, 60, 112)), True)
        self.agregar_objeto(ObjetoInteractivo("vestido", "Vestido de baño", (70, 205, 46, 30),
                                              visible_si=lambda h: h.capitulo == 4 and not h.tiene("fue_playa")))
        self.puertas.append(Puerta((440, ALTO - 26, 80, 26), "sala", (480, 150), "Sala"))
        self.spawns = {"inicio": (300, 300), "desde_sala": (480, 470)}

    def dibujar_fondo(self, sup, t, ctx):
        sup.fill((235, 215, 230), (0, HUD, ANCHO, 84))
        for x in range(0, ANCHO, 40):
            pygame.draw.line(sup, (225, 200, 220), (x, HUD), (x, self.top), 2)
        self.piso(sup, self.top, (196, 160, 128), (186, 150, 120))
        # ventana
        noche = ctx.noche
        pygame.draw.rect(sup, (25, 30, 70) if noche else (150, 210, 250), (270, 52, 90, 56), border_radius=4)
        if noche:
            pygame.draw.circle(sup, (250, 245, 210), (335, 68), 9)
        pygame.draw.rect(sup, (250, 250, 250), (270, 52, 90, 56), 4, border_radius=4)
        pygame.draw.line(sup, (250, 250, 250), (315, 52), (315, 108), 3)
        # afiche de baile
        pygame.draw.rect(sup, (255, 210, 90), (600, 52, 60, 44), border_radius=3)
        pygame.draw.circle(sup, (130, 90, 220), (630, 70), 9)
        pygame.draw.line(sup, (130, 90, 220), (630, 78), (622, 92), 3)
        pygame.draw.line(sup, (130, 90, 220), (630, 78), (640, 90), 3)
        # tapete
        pygame.draw.ellipse(sup, (170, 140, 220), (330, 300, 300, 120))
        pygame.draw.ellipse(sup, (190, 165, 235), (360, 315, 240, 90))
        # cama
        pygame.draw.rect(sup, (120, 80, 60), (40, 130, 190, 130), border_radius=8)
        pygame.draw.rect(sup, (250, 250, 255), (50, 138, 170, 40), border_radius=8)
        pygame.draw.rect(sup, (150, 120, 230), (46, 175, 178, 80), border_radius=8)
        if ctx.historia.capitulo == 4 and not ctx.historia.tiene("fue_playa"):
            pygame.draw.rect(sup, (60, 200, 210), (74, 208, 38, 24), border_radius=6)
            pygame.draw.line(sup, (255, 255, 255), (78, 214), (108, 214), 2)
        # mesita de noche con el celular
        pygame.draw.rect(sup, (150, 105, 70), (238, 136, 44, 40), border_radius=4)
        brillo = (abs(math.sin(t * 4)) * 120) if ctx.resaltar_celular else 0
        pygame.draw.rect(sup, (30, 30, 40), (251, 140, 18, 28), border_radius=4)
        pygame.draw.rect(sup, (120 + int(brillo), 200, 255), (254, 144, 12, 18), border_radius=2)
        if ctx.resaltar_celular:
            pygame.draw.circle(sup, (255, 230, 120), (260, 154), 22 + int(abs(math.sin(t * 4)) * 6), 2)
        # escritorio con dibujos
        pygame.draw.rect(sup, (150, 105, 70), (380, 120, 180, 60), border_radius=4)
        for i, c in enumerate([(255, 255, 255), (250, 245, 220), (255, 255, 255)]):
            pygame.draw.rect(sup, c, (395 + i * 52, 128 + (i % 2) * 6, 40, 30))
        pygame.draw.circle(sup, (240, 120, 120), (415, 142), 6)
        pygame.draw.line(sup, (90, 140, 230), (450, 136), (482, 156), 3)
        # clóset
        pygame.draw.rect(sup, (170, 120, 85), (620, 110, 120, 92), border_radius=4)
        pygame.draw.line(sup, (120, 85, 60), (680, 112), (680, 200), 3)
        # espejo
        pygame.draw.rect(sup, (220, 190, 120), (830, 118, 60, 112), border_radius=28)
        pygame.draw.rect(sup, (200, 230, 245), (838, 126, 44, 96), border_radius=22)
        pygame.draw.line(sup, (255, 255, 255), (850, 140), (860, 200), 3)
        # puerta
        pygame.draw.rect(sup, (110, 75, 55), (440, ALTO - 18, 80, 18))

    def dibujar_frente(self, sup, t, ctx):
        if ctx.noche:
            capa = pygame.Surface((ANCHO, ALTO - HUD), pygame.SRCALPHA)
            capa.fill((10, 15, 60, 120))
            pygame.draw.circle(capa, (0, 0, 0, 0), (260, 154), 60)
            sup.blit(capa, (0, HUD))


# ------------------------------------------------------------------ SALA
class Sala(Mapa):
    id, nombre = "sala", "Sala y cocina"

    def construir(self):
        self.top = self.paredes(puerta_arriba=(440, 520), puerta_der=(280, 380), alto_pared=70)
        self.agregar_objeto(ObjetoInteractivo("cocina", "Cocina", (30, 106, 320, 60)), True)
        self.agregar_objeto(ObjetoInteractivo("mesa", "Mesa", (400, 270, 170, 76)), True)
        self.agregar_objeto(ObjetoInteractivo("sofa", "Sofá", (660, 118, 240, 62)), True)
        self.agregar_objeto(ObjetoInteractivo("foto_familiar", "Foto familiar", (590, 50, 50, 50)))
        self.puertas.append(Puerta((440, HUD + 52, 80, 24), "cuarto", (480, 470), "Cuarto"))
        self.puertas.append(Puerta((ANCHO - 30, 280, 30, 100), "colegio", (75, 330), "Salir"))
        self.spawns = {"desde_cuarto": (480, 150), "desde_colegio": (880, 330)}

    def dibujar_fondo(self, sup, t, ctx):
        sup.fill((250, 225, 180), (0, HUD, ANCHO, 70))
        self.piso(sup, self.top, (225, 205, 175), (215, 195, 165), 60)
        pygame.draw.rect(sup, (130, 90, 60), (440, HUD + 4, 80, 66))
        # foto familiar
        pygame.draw.rect(sup, (150, 110, 70), (592, 52, 46, 40))
        pygame.draw.rect(sup, (200, 230, 250), (597, 57, 36, 30))
        for i in range(3):
            pygame.draw.circle(sup, (180, 130, 100), (604 + i * 11, 74), 4 - (i == 2))
        # cocina
        pygame.draw.rect(sup, (240, 240, 245), (30, 106, 320, 60), border_radius=4)
        pygame.draw.rect(sup, (60, 60, 70), (60, 116, 70, 40), border_radius=3)
        for cx in (78, 112):
            pygame.draw.circle(sup, (200, 60, 50) if ctx.historia.capitulo in (1, 3) else (90, 90, 100), (cx, 136), 9, 3)
        pygame.draw.rect(sup, (170, 200, 220), (200, 118, 70, 36), border_radius=6)
        # mesa
        pygame.draw.rect(sup, (165, 115, 75), (400, 270, 170, 76), border_radius=6)
        for cx in (430, 540):
            pygame.draw.circle(sup, (250, 250, 250), (cx, 300), 14)
        pygame.draw.circle(sup, (240, 200, 110), (430, 300), 8)
        for x in (410, 520):
            pygame.draw.rect(sup, (130, 90, 60), (x, 350, 40, 22), border_radius=4)
        # sofá y tele
        pygame.draw.rect(sup, (90, 120, 190), (660, 118, 240, 62), border_radius=12)
        pygame.draw.rect(sup, (110, 140, 210), (670, 128, 220, 30), border_radius=8)
        pygame.draw.rect(sup, (30, 30, 35), (720, 440, 120, 50), border_radius=4)
        pygame.draw.rect(sup, (80, 140, 200), (727, 446, 106, 38))
        # planta
        pygame.draw.rect(sup, (190, 100, 70), (900, 440, 30, 30))
        for a in range(5):
            pygame.draw.ellipse(sup, (70, 160, 90), (895 + a * 6 - 6, 410 + (a % 2) * 8, 18, 34))
        pygame.draw.rect(sup, (130, 90, 60), (ANCHO - 18, 280, 18, 100))


# ------------------------------------------------------------------ COLEGIO
class Colegio(Mapa):
    id, nombre = "colegio", "Colegio"

    def construir(self):
        self.top = self.paredes(puerta_izq=(280, 380), alto_pared=110)
        self.agregar_objeto(ObjetoInteractivo("cartelera", "Cartelera", (760, 112, 130, 50)))
        self.agregar_objeto(ObjetoInteractivo("arbol", "Árbol", (640, 300, 30, 40)), True)
        self.solidos += [pygame.Rect(200, 380, 120, 26), pygame.Rect(400, 440, 120, 26)]
        self.puertas.append(Puerta((0, 280, 30, 100), "sala", (880, 330), "Casa"))
        self.spawns = {"desde_sala": (75, 330)}

    def dibujar_fondo(self, sup, t, ctx):
        sup.fill((240, 200, 150), (0, HUD, ANCHO, 110))
        for x in range(40, ANCHO, 140):
            pygame.draw.rect(sup, (150, 200, 240), (x, 56, 70, 50), border_radius=4)
            pygame.draw.rect(sup, (255, 255, 255), (x, 56, 70, 50), 3, border_radius=4)
        self.texto_letrero(sup, ctx)
        self.piso(sup, self.top, (205, 205, 210), (195, 195, 200), 60)
        pygame.draw.rect(sup, (110, 180, 100), (700, 380, 220, 120), border_radius=20)
        # cartelera
        pygame.draw.rect(sup, (160, 110, 70), (760, 112, 130, 50), border_radius=4)
        pygame.draw.rect(sup, (245, 235, 200), (766, 116, 118, 40))
        pygame.draw.rect(sup, (255, 120, 150), (772, 120, 50, 30))
        pygame.draw.rect(sup, (130, 100, 230), (828, 120, 50, 30))
        pygame.draw.circle(sup, (255, 255, 255), (797, 132), 5)
        pygame.draw.line(sup, (255, 255, 255), (797, 137), (790, 147), 2)
        pygame.draw.line(sup, (255, 255, 255), (797, 137), (804, 146), 2)
        # bancas
        for x, y in ((200, 380), (400, 440)):
            pygame.draw.rect(sup, (150, 100, 60), (x, y, 120, 20), border_radius=4)
            pygame.draw.rect(sup, (110, 70, 45), (x + 8, y + 18, 8, 10))
            pygame.draw.rect(sup, (110, 70, 45), (x + 104, y + 18, 8, 10))
        pygame.draw.rect(sup, (120, 85, 55), (640, 300, 30, 40))
        pygame.draw.rect(sup, (130, 90, 60), (0, 280, 18, 100))

    def texto_letrero(self, sup, ctx):
        r = pygame.Rect(330, 110, 300, 0)
        ctx.dibujo.texto(sup, "COLEGIO NUEVA ESPERANZA", (480, 128), (90, 60, 40), "peq", "center")

    def dibujar_frente(self, sup, t, ctx):
        for dx, dy, r in ((-20, -40, 45), (25, -50, 40), (0, -75, 42)):
            pygame.draw.circle(sup, (60, 140, 80), (655 + dx, 300 + dy), r)


# ------------------------------------------------------------------ PLAYA
class Playa(Mapa):
    id, nombre = "playa", "La playa"

    def construir(self):
        self.solidos += [pygame.Rect(0, HUD, ANCHO, 150), pygame.Rect(0, HUD, 18, ALTO), pygame.Rect(ANCHO - 18, HUD, 18, ALTO),
                         pygame.Rect(0, ALTO - 14, ANCHO, 14)]
        self.agregar_objeto(ObjetoInteractivo("mar", "El mar", (300, 176, 360, 14)))
        self.agregar_objeto(ObjetoInteractivo("castillo", "Castillo de arena", (700, 330, 54, 36)), True)
        self.agregar_objeto(ObjetoInteractivo("nevera", "Nevera", (100, 430, 54, 32)), True)
        self.solidos.append(pygame.Rect(152, 300, 14, 20))
        self.spawns = {"llegada": (480, 470)}

    def dibujar_fondo(self, sup, t, ctx):
        tarde = ctx.atardecer
        cielo = (250, 160, 110) if tarde else (150, 210, 245)
        sup.fill(cielo, (0, HUD, ANCHO, 40))
        if tarde:
            pygame.draw.circle(sup, (255, 210, 120), (720, HUD + 40), 30)
        for i in range(6):
            y = HUD + 40 + i * 24
            col = (40 + i * 12, 120 + i * 12, 190 + i * 8) if not tarde else (170 + i * 8, 100 + i * 10, 140 + i * 6)
            sup.fill(col, (0, y, ANCHO, 24))
            pts = [(x, y + 4 + math.sin(x / 40 + t * 2 + i) * 3) for x in range(0, ANCHO + 20, 20)]
            pygame.draw.lines(sup, (230, 245, 255), False, pts, 2)
        sup.fill((240, 220, 160), (0, HUD + 184, ANCHO, ALTO))
        espuma = [(x, HUD + 182 + math.sin(x / 30 + t * 2.5) * 5) for x in range(0, ANCHO + 20, 15)]
        pygame.draw.lines(sup, (255, 255, 255), False, espuma, 6)
        for x, y in ((240, 420), (520, 360), (860, 470), (380, 500)):
            pygame.draw.circle(sup, (225, 200, 140), (x, y), 3)
        # toalla y sombrilla
        pygame.draw.rect(sup, (240, 110, 120), (180, 330, 90, 50), border_radius=6)
        pygame.draw.rect(sup, (255, 255, 255), (180, 345, 90, 8))
        pygame.draw.line(sup, (120, 90, 60), (158, 318), (158, 250), 4)
        # castillo
        pygame.draw.rect(sup, (215, 180, 110), (700, 336, 54, 30))
        for i in range(3):
            pygame.draw.rect(sup, (215, 180, 110), (702 + i * 18, 322, 14, 16))
        pygame.draw.polygon(sup, (240, 90, 90), [(727, 300), (727, 318), (742, 309)])
        pygame.draw.line(sup, (90, 70, 50), (727, 300), (727, 324), 2)
        # nevera
        pygame.draw.rect(sup, (60, 140, 220), (100, 430, 54, 32), border_radius=5)
        pygame.draw.rect(sup, (255, 255, 255), (100, 430, 54, 9), border_radius=5)

    def dibujar_frente(self, sup, t, ctx):
        pygame.draw.circle(sup, (255, 200, 70), (158, 250), 58, draw_top_right=True, draw_top_left=True)
        pygame.draw.line(sup, (255, 255, 255), (100, 250), (216, 250), 3)
        if ctx.atardecer:
            capa = pygame.Surface((ANCHO, ALTO - HUD), pygame.SRCALPHA)
            capa.fill((255, 120, 60, 45))
            sup.blit(capa, (0, HUD))


def crear_mapas():
    return {m.id: m for m in (Cuarto(), Sala(), Colegio(), Playa())}
