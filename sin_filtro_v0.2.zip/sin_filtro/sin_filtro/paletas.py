"""Patrón Strategy: paletas de la interfaz (componente inclusivo)."""
from abc import ABC, abstractmethod


class PaletaStrategy(ABC):
    @property
    @abstractmethod
    def nombre(self): ...

    @property
    @abstractmethod
    def colores(self): ...

    def __getitem__(self, k):
        return self.colores[k]


class PaletaNormal(PaletaStrategy):
    nombre = "Normal"
    colores = {"panel": (30, 26, 52), "borde": (150, 130, 255), "texto": (245, 242, 252),
               "suave": (180, 172, 210), "acento": (255, 200, 70), "algo": (255, 70, 170),
               "bien": (90, 200, 140), "mal": (240, 90, 100), "sel": (110, 90, 230)}


class PaletaDaltonismo(PaletaStrategy):
    nombre = "Daltonismo"
    colores = {"panel": (24, 32, 48), "borde": (80, 160, 255), "texto": (245, 245, 245),
               "suave": (185, 195, 210), "acento": (255, 160, 40), "algo": (255, 140, 0),
               "bien": (70, 150, 255), "mal": (255, 140, 0), "sel": (50, 110, 210)}


class PaletaAltoContraste(PaletaStrategy):
    nombre = "Alto contraste"
    colores = {"panel": (0, 0, 0), "borde": (255, 255, 255), "texto": (255, 255, 255),
               "suave": (230, 230, 230), "acento": (255, 255, 0), "algo": (255, 255, 0),
               "bien": (0, 255, 255), "mal": (255, 255, 0), "sel": (90, 90, 90)}


PALETAS = [PaletaNormal(), PaletaDaltonismo(), PaletaAltoContraste()]
