"""TAD propios (Estructura de Datos): Pila, Cola y Árbol de decisiones (n-ario)."""


class Nodo:
    __slots__ = ("valor", "siguiente")

    def __init__(self, valor, siguiente=None):
        self.valor = valor
        self.siguiente = siguiente


class Pila:
    """LIFO enlazada. Uso: navegación de pantallas y ramas del guion (pila de colas)."""

    def __init__(self):
        self._tope = None
        self._tam = 0

    def push(self, valor):
        self._tope = Nodo(valor, self._tope)
        self._tam += 1

    def pop(self):
        if self._tope is None:
            raise IndexError("pop sobre pila vacía")
        valor = self._tope.valor
        self._tope = self._tope.siguiente
        self._tam -= 1
        return valor

    def peek(self):
        return None if self._tope is None else self._tope.valor

    def esta_vacia(self):
        return self._tope is None

    def __len__(self):
        return self._tam

    def __iter__(self):
        elementos, actual = [], self._tope
        while actual:
            elementos.append(actual.valor)
            actual = actual.siguiente
        return iter(reversed(elementos))


class Cola:
    """FIFO enlazada. Uso: acciones de una cinemática y mensajes en pantalla."""

    def __init__(self):
        self._frente = None
        self._final = None
        self._tam = 0

    def encolar(self, valor):
        nodo = Nodo(valor)
        if self._final:
            self._final.siguiente = nodo
        else:
            self._frente = nodo
        self._final = nodo
        self._tam += 1

    def desencolar(self):
        if self._frente is None:
            raise IndexError("desencolar sobre cola vacía")
        valor = self._frente.valor
        self._frente = self._frente.siguiente
        if self._frente is None:
            self._final = None
        self._tam -= 1
        return valor

    def esta_vacia(self):
        return self._frente is None

    def __len__(self):
        return self._tam


class NodoDecision:
    def __init__(self, decision, opcion, padre=None):
        self.decision = decision
        self.opcion = opcion
        self.padre = padre
        self.hijos = {}


class ArbolDecisiones:
    """Árbol n-ario: cada partida es un camino desde la raíz. Acumula los caminos de varias partidas."""

    def __init__(self):
        self.raiz = NodoDecision(None, None)
        self.actual = self.raiz

    def nuevo_recorrido(self):
        self.actual = self.raiz

    def registrar(self, decision, opcion):
        clave = (decision, opcion)
        if clave not in self.actual.hijos:
            self.actual.hijos[clave] = NodoDecision(decision, opcion, self.actual)
        self.actual = self.actual.hijos[clave]

    def camino_actual(self):
        camino, nodo = [], self.actual
        while nodo is not self.raiz:
            camino.append((nodo.decision, nodo.opcion))
            nodo = nodo.padre
        return list(reversed(camino))

    def contar_hojas(self, nodo=None):
        nodo = nodo or self.raiz
        if not nodo.hijos:
            return 0 if nodo is self.raiz else 1
        return sum(self.contar_hojas(h) for h in nodo.hijos.values())

    def altura(self, nodo=None):
        nodo = nodo or self.raiz
        if not nodo.hijos:
            return 0
        return 1 + max(self.altura(h) for h in nodo.hijos.values())
