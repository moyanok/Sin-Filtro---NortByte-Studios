"""Clase principal: ciclo de juego, gestor de estados (Pila propia) y subtítulos de sonido."""
import pygame

from sin_filtro import eventos as ev
from sin_filtro.config import ALTO, ANCHO, FPS, TITULO, Ajustes
from sin_filtro.dibujo import Dibujo
from sin_filtro.estructuras import Pila
from sin_filtro.historia import GestorHistoria
from sin_filtro.paletas import PALETAS
from sin_filtro.sonido import GestorSonido


class Juego:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(TITULO)
        try:
            self.pantalla = pygame.display.set_mode((ANCHO, ALTO), pygame.SCALED | pygame.RESIZABLE)
        except pygame.error:
            self.pantalla = pygame.display.set_mode((ANCHO, ALTO))
        self.reloj = pygame.time.Clock()
        self.ajustes = Ajustes()
        self.bus = ev.EventBus()
        self.dibujo = Dibujo()
        self.sonido = GestorSonido(self.bus, self.ajustes)
        self.historia = GestorHistoria(self.bus)
        self.estados = Pila()
        self.corriendo = True
        self.subtitulo, self.t_sub = None, 0.0
        self.bus.suscribir(ev.SONIDO, self._subtitular)

    @property
    def paleta(self):
        return PALETAS[self.ajustes.paleta]

    def _subtitular(self, nombre=None, subtitulo=None, **_):
        if subtitulo and self.ajustes.subtitulos:
            self.subtitulo, self.t_sub = subtitulo, 1.8

    # ---- estados ----
    def apilar(self, estado):
        self.estados.push(estado)
        estado.al_entrar()

    def desapilar(self):
        if len(self.estados) > 1:
            self.estados.pop()

    def reemplazar(self, estado):
        self.estados.pop()
        self.apilar(estado)

    def reiniciar_a(self, estado):
        self.estados = Pila()
        self.apilar(estado)

    def salir(self):
        self.corriendo = False

    def capas_visibles(self):
        capas = list(self.estados)
        inicio = 0
        for i, e in enumerate(capas):
            if not e.transparente:
                inicio = i
        return capas[inicio:]

    def paso(self, dt, eventos=()):
        for e in eventos:
            if e.type == pygame.QUIT:
                self.corriendo = False
            elif e.type == pygame.KEYDOWN and e.key == pygame.K_F11:
                pygame.display.toggle_fullscreen()
            else:
                self.estados.peek().manejar_evento(e)
        self.estados.peek().actualizar(dt)
        self.t_sub = max(0.0, self.t_sub - dt)
        for capa in self.capas_visibles():
            capa.dibujar(self.pantalla)
        if self.subtitulo and self.t_sub > 0:
            r = self.dibujo.f["peq"].render(self.subtitulo, True, (255, 255, 255))
            fondo = pygame.Rect(0, 0, r.get_width() + 16, r.get_height() + 8)
            fondo.topright = (ANCHO - 8, 42)
            pygame.draw.rect(self.pantalla, (0, 0, 0), fondo, border_radius=6)
            self.pantalla.blit(r, (fondo.x + 8, fondo.y + 4))

    def ejecutar(self):
        from sin_filtro.estados.menus import EstadoTitulo
        self.apilar(EstadoTitulo(self))
        while self.corriendo:
            dt = min(self.reloj.tick(FPS) / 1000.0, 0.05)
            self.paso(dt, pygame.event.get())
            pygame.display.flip()
        pygame.quit()
