"""Pantallas de menú: título, creación de Vale, pausa, ayuda y opciones."""
import math

import pygame

from sin_filtro import eventos as ev
from sin_filtro.acciones import CONFIRMAR, es_confirmar
from sin_filtro.config import (ALTO, ANCHO, COLORES_PELO, ESTILOS_PELO, NOMBRES_COLOR_PELO, NOMBRES_ROPA, PIELES,
                               ROPAS, VELOCIDADES_TEXTO)
from sin_filtro.estados.base import Estado
from sin_filtro.paletas import PALETAS
from sin_filtro.personajes import Apariencia


class MenuLista(Estado):
    """Base para menús verticales navegables con W/S, flechas, Enter o mouse."""

    opciones = []
    y0, alto_fila, ancho = 300, 58, 380

    def __init__(self, juego):
        super().__init__(juego)
        self.sel = 0
        self.aviso = ""

    def rect(self, i):
        r = pygame.Rect(0, 0, self.ancho, self.alto_fila - 10)
        r.center = (ANCHO // 2, self.y0 + i * self.alto_fila)
        return r

    def ejecutar(self, i): ...

    def manejar_evento(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_w, pygame.K_UP):
                self.sel = (self.sel - 1) % len(self.opciones)
                self.juego.bus.publicar(ev.SONIDO, nombre="mover")
            elif e.key in (pygame.K_s, pygame.K_DOWN):
                self.sel = (self.sel + 1) % len(self.opciones)
                self.juego.bus.publicar(ev.SONIDO, nombre="mover")
            elif e.key in CONFIRMAR:
                self.juego.bus.publicar(ev.SONIDO, nombre="elegir")
                self.ejecutar(self.sel)
            elif e.key == pygame.K_ESCAPE:
                self.al_escape()
            else:
                self.aviso = "Usa W/S o las flechas y Enter. También puedes usar el mouse."
        elif e.type == pygame.MOUSEMOTION:
            for i in range(len(self.opciones)):
                if self.rect(i).collidepoint(e.pos):
                    self.sel = i
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i in range(len(self.opciones)):
                if self.rect(i).collidepoint(e.pos):
                    self.ejecutar(i)
                    return

    def al_escape(self):
        pass

    def dibujar_opciones(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        for i, op in enumerate(self.opciones):
            r = self.rect(i)
            d.panel(sup, r, pal, pal["acento"] if i == self.sel else pal["borde"], 12, 240)
            if i == self.sel:
                pygame.draw.rect(sup, pal["sel"], r.inflate(-6, -6), border_radius=10)
            d.texto(sup, op, r.center, pal["texto"], "normal", "center")
        if self.aviso:
            d.texto(sup, self.aviso, (ANCHO // 2, ALTO - 30), pal["acento"], "peq", "center")


class EstadoTitulo(MenuLista):
    opciones = ["Nueva historia", "Cómo jugar", "Opciones", "Salir"]
    y0 = 296

    def __init__(self, juego):
        super().__init__(juego)
        self.t = 0.0

    def ejecutar(self, i):
        if i == 0:
            self.juego.apilar(EstadoCreacion(self.juego))
        elif i == 1:
            self.juego.apilar(EstadoAyuda(self.juego))
        elif i == 2:
            self.juego.apilar(EstadoOpciones(self.juego))
        else:
            self.juego.salir()

    def actualizar(self, dt):
        self.t += dt

    def dibujar(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        for y in range(0, ALTO, 6):
            sup.fill((28 + y // 30, 20 + y // 40, 50 + y // 20), (0, y, ANCHO, 6))
        # celular con un feed que no para
        tel = pygame.Rect(60, 210, 160, 290)
        pygame.draw.rect(sup, (15, 15, 22), tel, border_radius=24)
        pant = tel.inflate(-16, -22)
        sup.set_clip(pant)
        pygame.draw.rect(sup, (240, 240, 248), pant)
        off = (self.t * 60) % 90
        for k in range(5):
            y = pant.y - off + k * 90
            pygame.draw.rect(sup, [(250, 190, 200), (190, 210, 250), (210, 250, 200)][k % 3], (pant.x + 10, y + 8, pant.w - 20, 60), border_radius=6)
            self.juego.dibujo.corazon(sup, pant.x + 20, y + 78, 5, (235, 70, 110))
        sup.set_clip(None)
        d.algo(sup, 250, 250, self.t, 1.4, 0.6)
        # Vale de espaldas al celular, mirando hacia adelante
        d.personaje(sup, ANCHO - 180, 420, Apariencia.desde_ajustes(self.juego.ajustes), "abajo", self.t, False, 2.6, "feliz")
        titulo = d.f["titulo"].render("SIN FILTRO", True, (255, 255, 255))
        sombra = d.f["titulo"].render("SIN FILTRO", True, (255, 70, 170))
        jit = 3 if int(self.t * 3) % 7 == 0 else 0
        sup.blit(sombra, sombra.get_rect(center=(ANCHO // 2 + 3 + jit, 113)))
        sup.blit(titulo, titulo.get_rect(center=(ANCHO // 2, 110)))
        d.texto(sup, "Una historia sobre redes sociales, espejos y lo que de verdad importa", (ANCHO // 2, 168), pal["suave"], "peq", "center")
        self.dibujar_opciones(sup)
        d.texto(sup, "NorteByte Studios · Uninorte 2026-30", (ANCHO // 2, ALTO - 12), pal["suave"], "mini", "midbottom")


class EstadoCreacion(Estado):
    """Elegir cómo se ve Vale. Ninguna opción es 'mejor': todas son Vale (componente inclusivo)."""

    FILAS = ["Tono de piel", "Peinado", "Color de pelo", "Contextura", "Ropa", "Comenzar"]

    def __init__(self, juego):
        super().__init__(juego)
        self.sel = 0
        self.t = 0.0

    def _cambiar(self, delta):
        aj = self.juego.ajustes
        campo, n = [("piel", len(PIELES)), ("pelo_estilo", len(ESTILOS_PELO)), ("pelo_color", len(COLORES_PELO)),
                    ("contextura", 3), ("ropa", len(ROPAS))][self.sel]
        setattr(aj, campo, (getattr(aj, campo) + delta) % n)
        self.juego.bus.publicar(ev.SONIDO, nombre="mover")

    def _valor(self, i):
        aj = self.juego.ajustes
        return [f"Tono {aj.piel + 1}", ESTILOS_PELO[aj.pelo_estilo].capitalize(), NOMBRES_COLOR_PELO[aj.pelo_color],
                f"Contextura {aj.contextura + 1}", NOMBRES_ROPA[aj.ropa], ""][i]

    def _fila(self, i):
        return pygame.Rect(470, 120 + i * 62, 440, 50)

    def _comenzar(self):
        from sin_filtro.estados.exploracion import EstadoExploracion
        self.juego.historia.reiniciar()
        self.juego.bus.publicar(ev.SONIDO, nombre="logro")
        self.juego.reiniciar_a(EstadoExploracion(self.juego, self.juego.historia))

    def manejar_evento(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_w, pygame.K_UP):
                self.sel = (self.sel - 1) % len(self.FILAS)
            elif e.key in (pygame.K_s, pygame.K_DOWN):
                self.sel = (self.sel + 1) % len(self.FILAS)
            elif e.key in (pygame.K_a, pygame.K_LEFT) and self.sel < 5:
                self._cambiar(-1)
            elif e.key in (pygame.K_d, pygame.K_RIGHT) and self.sel < 5:
                self._cambiar(1)
            elif e.key in CONFIRMAR:
                self._comenzar() if self.sel == 5 else self._cambiar(1)
            elif e.key == pygame.K_ESCAPE:
                self.juego.desapilar()
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i in range(len(self.FILAS)):
                r = self._fila(i)
                if r.collidepoint(e.pos):
                    self.sel = i
                    if i == 5:
                        self._comenzar()
                    else:
                        self._cambiar(-1 if e.pos[0] < r.centerx else 1)

    def actualizar(self, dt):
        self.t += dt

    def dibujar(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        sup.fill((32, 26, 56))
        d.texto(sup, "Ella es Vale", (240, 60), pal["texto"], "grande", "center")
        pygame.draw.ellipse(sup, (60, 50, 100), (110, 400, 260, 50))
        ap = Apariencia.desde_ajustes(self.juego.ajustes)
        d.personaje(sup, 240, 425, ap, ["abajo", "der", "abajo", "izq"][int(self.t / 1.5) % 4], self.t, True, 3.4, "feliz")
        d.parrafo(sup, "Elige cómo se ve. Todas las opciones son Vale: ninguna es mejor que otra.",
                  60, 470, 360, pal["suave"], "peq", centrado=True)
        d.texto(sup, "Antes de empezar", (690, 70), pal["acento"], "grande", "center")
        for i, fila in enumerate(self.FILAS):
            r = self._fila(i)
            sel = i == self.sel
            d.panel(sup, r, pal, pal["acento"] if sel else pal["borde"], 12, 240)
            if sel:
                pygame.draw.rect(sup, pal["sel"], r.inflate(-6, -6), border_radius=10)
            if i == 5:
                d.texto(sup, "Comenzar la historia", r.center, pal["texto"], "normal", "center")
            else:
                d.texto(sup, fila, (r.x + 16, r.centery), pal["texto"], "normal", "midleft")
                d.texto(sup, f"<  {self._valor(i)}  >", (r.right - 16, r.centery), pal["texto"], "normal", "midright")
        d.texto(sup, "W/S: elegir fila · A/D: cambiar · Enter: comenzar", (690, ALTO - 24), pal["suave"], "peq", "center")


class EstadoPausa(MenuLista):
    transparente = True
    opciones = ["Continuar", "Cómo jugar", "Opciones", "Volver al título"]
    y0 = 220

    def ejecutar(self, i):
        if i == 0:
            self.juego.desapilar()
        elif i == 1:
            self.juego.apilar(EstadoAyuda(self.juego))
        elif i == 2:
            self.juego.apilar(EstadoOpciones(self.juego))
        else:
            self.juego.reiniciar_a(EstadoTitulo(self.juego))

    def al_escape(self):
        self.juego.desapilar()

    def dibujar(self, sup):
        velo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        velo.fill((0, 0, 0, 170))
        sup.blit(velo, (0, 0))
        self.juego.dibujo.texto(sup, "PAUSA", (ANCHO // 2, 130), (255, 255, 255), "titulo", "center")
        self.dibujar_opciones(sup)


class EstadoAyuda(Estado):
    """Herramienta de AYUDA (requerimiento de usabilidad)."""

    transparente = True
    PAGINAS = [
        ("De qué se trata", "Acompañas a Vale durante cuatro días de su semana. Ella vive la presión de las redes "
                            "por tener un 'cuerpo perfecto'. Tus decisiones cambian cómo se siente, cómo le va con "
                            "su familia y amigos, y cómo termina la historia. Hay tres finales."),
        ("Controles", "W A S D o flechas: caminar.\nE o Espacio: hablar, usar objetos y avanzar el diálogo.\n"
                      "En las decisiones: W/S y Enter, el número de la opción o clic.\nEsc o P: pausa.   H: esta ayuda."),
        ("Objetivos", "Arriba de la pantalla siempre ves el objetivo actual. Cuando estés cerca de algo con lo que "
                      "puedes interactuar, aparece 'E: ...' encima de Vale."),
        ("Algo", "Algo es el algoritmo de la red social. Te habla desde el celular y quiere que sigas mirando. "
                 "Arriba a la derecha, su ojo crece cuando tiene más poder sobre Vale. El espejito a su lado brilla "
                 "más cuando Vale se siente mejor."),
        ("Minijuegos", "Editor: decide cuánto editar una foto.\nDetecta el filtro: encuentra las pistas de edición "
                       "antes de que se acabe el tiempo.\nSal del feed: esquiva lo que te quita el sueño y recoge "
                       "lo que te ayuda a dormir."),
        ("Accesibilidad", "En Opciones puedes cambiar la paleta (daltonismo o alto contraste), la velocidad del texto, "
                          "el sonido y los subtítulos de los sonidos. Todo el diálogo está escrito en pantalla."),
    ]

    def __init__(self, juego):
        super().__init__(juego)
        self.pag = 0

    def manejar_evento(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_d, pygame.K_RIGHT):
                self.pag = min(len(self.PAGINAS) - 1, self.pag + 1)
            elif e.key in (pygame.K_a, pygame.K_LEFT):
                self.pag = max(0, self.pag - 1)
            elif e.key in (pygame.K_ESCAPE, pygame.K_h, pygame.K_RETURN, pygame.K_e, pygame.K_SPACE):
                self.juego.desapilar()
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            if e.pos[0] > ANCHO * 0.7:
                self.pag = min(len(self.PAGINAS) - 1, self.pag + 1)
            elif e.pos[0] < ANCHO * 0.3:
                self.pag = max(0, self.pag - 1)
            else:
                self.juego.desapilar()

    def dibujar(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        velo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        velo.fill((0, 0, 0, 190))
        sup.blit(velo, (0, 0))
        caja = pygame.Rect(120, 70, ANCHO - 240, ALTO - 150)
        d.panel(sup, caja, pal)
        titulo, cuerpo = self.PAGINAS[self.pag]
        d.texto(sup, "AYUDA · " + titulo, (caja.centerx, caja.y + 40), pal["acento"], "grande", "center")
        d.parrafo(sup, cuerpo, caja.x + 40, caja.y + 90, caja.w - 80, pal["texto"], "normal", 8)
        d.texto(sup, f"<  A   {self.pag + 1} / {len(self.PAGINAS)}   D  >      Esc: volver", (ANCHO // 2, caja.bottom + 30),
                pal["suave"], "peq", "center")


class EstadoOpciones(MenuLista):
    transparente = True
    y0 = 200
    ancho = 520

    @property
    def opciones(self):
        aj = self.juego.ajustes
        return [f"Paleta: {PALETAS[aj.paleta].nombre}", f"Velocidad del texto: {VELOCIDADES_TEXTO[aj.velocidad][0]}",
                f"Sonido: {'Sí' if aj.sonido else 'No'}", f"Subtítulos de sonidos: {'Sí' if aj.subtitulos else 'No'}",
                "Volver"]

    def ejecutar(self, i):
        aj = self.juego.ajustes
        if i == 0:
            aj.paleta = (aj.paleta + 1) % len(PALETAS)
        elif i == 1:
            aj.velocidad = (aj.velocidad + 1) % len(VELOCIDADES_TEXTO)
        elif i == 2:
            aj.sonido = not aj.sonido
        elif i == 3:
            aj.subtitulos = not aj.subtitulos
        else:
            self.juego.desapilar()

    def al_escape(self):
        self.juego.desapilar()

    def dibujar(self, sup):
        velo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        velo.fill((10, 8, 20, 225))
        sup.blit(velo, (0, 0))
        self.juego.dibujo.texto(sup, "Opciones", (ANCHO // 2, 110), (255, 255, 255), "titulo", "center")
        self.dibujar_opciones(sup)
