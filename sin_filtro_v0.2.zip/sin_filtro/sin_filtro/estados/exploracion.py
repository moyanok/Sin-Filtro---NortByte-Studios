"""Exploración: Vale camina con WASD, habla con personas, usa objetos y vive las cinemáticas."""
import math
import random

import pygame

from sin_filtro import eventos as ev
from sin_filtro.acciones import CONFIRMAR, Fundido, IrA, Sonido
from sin_filtro.capitulos import CAPITULOS, P
from sin_filtro.config import ALTO, ANCHO, HUD
from sin_filtro.estados.base import Estado
from sin_filtro.guion import Guion
from sin_filtro.mapas import crear_mapas
from sin_filtro.personajes import Apariencia, Jugador, crear_reparto

RANGO = 34


class EstadoExploracion(Estado):
    def __init__(self, juego, historia):
        super().__init__(juego)
        self.historia = historia
        self.bus = juego.bus
        self.dibujo = juego.dibujo
        self.rng = random.Random()
        ap = Apariencia.desde_ajustes(juego.ajustes)
        self.jugador = Jugador("vale", "Vale", ap)
        self.reparto = crear_reparto(ap)
        self.mapas = crear_mapas()
        self.guion = Guion()
        self.fade, self.glitch, self.flash, self.t = 255.0, 0.0, 0.0, 0.0
        self.noche = self.atardecer = self.resaltar_celular = False
        self.emotes = []
        self.aviso = None
        self.cargar_capitulo(0)

    @property
    def paleta(self):
        return self.juego.paleta

    # ------------------------------------------------ capítulos y pasos
    def cargar_capitulo(self, indice):
        self.indice = indice
        self.cap = CAPITULOS[indice]()
        self.historia.capitulo = self.cap.numero
        self.npcs_por_mapa = {m: [(i, x, y, d) for i, x, y, d in lista] for m, lista in self.cap.npcs.items()}
        self.paso = None
        self.guion.limpiar()
        self.atardecer = False
        self.ir_a(*self.cap.inicio)
        self.jugador.dir = "abajo"
        self.guion.agregar(self.cap.intro())

    def siguiente_capitulo(self):
        if self.indice + 1 < len(CAPITULOS):
            self.cargar_capitulo(self.indice + 1)
        else:
            self.terminar_historia()

    def avanzar_paso(self, destino=None):
        nombre = destino or (self.paso.siguiente if self.paso else self.cap.paso_inicial)
        self.paso = self.cap.pasos[nombre] if nombre else None
        if self.paso and self.paso.objetivo_id is None:
            self.guion.insertar(self.paso.guion())

    def terminar_historia(self):
        from sin_filtro.estados.escenas import EstadoFinal
        self.guion.limpiar()
        self.juego.reemplazar(EstadoFinal(self.juego, self.historia, self.jugador.ap, self.reparto))

    # ------------------------------------------------ mundo
    def ir_a(self, mapa_id, spawn):
        self.mapa = self.mapas[mapa_id]
        x, y = self.mapa.spawns[spawn] if isinstance(spawn, str) else spawn
        self.jugador.x, self.jugador.y = x, y
        self.npcs = {}
        for id_, nx, ny, d in self.npcs_por_mapa.get(mapa_id, []):
            npc = self.reparto[id_]
            npc.x, npc.y, npc.dir, npc.caminando = nx, ny, d, False
            self.npcs[id_] = npc

    def colocar_npc(self, id_, mapa, x, y, d):
        self.npcs_por_mapa.setdefault(mapa, []).append((id_, x, y, d))
        if self.mapa.id == mapa:
            npc = self.reparto[id_]
            npc.x, npc.y, npc.dir = x, y, d
            self.npcs[id_] = npc

    def quitar_npc(self, id_, mapa):
        self.npcs_por_mapa[mapa] = [n for n in self.npcs_por_mapa.get(mapa, []) if n[0] != id_]
        if self.mapa.id == mapa:
            self.npcs.pop(id_, None)

    def personaje(self, quien):
        if quien in ("vale", "piensa"):
            return self.jugador
        return self.npcs.get(quien)

    def colisiona(self, rect):
        if not pygame.Rect(10, HUD, ANCHO - 20, ALTO - HUD).contains(rect):
            dentro_puerta = any(p.rect.colliderect(rect) for p in self.mapa.puertas)
            if not dentro_puerta:
                return True
        if rect.collidelist(self.mapa.solidos) != -1:
            return True
        return any(rect.colliderect(n.pies) for n in self.npcs.values())

    def _cercano(self):
        px, py = self.jugador.x, self.jugador.y - 10
        mejor, mejor_d = None, RANGO
        for n in self.npcs.values():
            d = math.hypot(n.x - px, n.y - 10 - py)
            if d < mejor_d + 14:
                mejor, mejor_d = ("npc", n.id, n.nombre), d - 14
        for o in self.mapa.objetos.values():
            if not o.visible(self.historia):
                continue
            cx = max(o.rect.left, min(px, o.rect.right))
            cy = max(o.rect.top, min(py, o.rect.bottom))
            d = math.hypot(cx - px, cy - py)
            if d < RANGO and d + o.prioridad < mejor_d:
                d += o.prioridad
                mejor, mejor_d = ("obj", o.id, o.nombre), d
        return mejor

    def _interactuar(self):
        cercano = self._cercano()
        if not cercano:
            return
        tipo, id_, _ = cercano
        if tipo == "npc":
            self.npcs[id_].mirar_a(self.jugador)
        paso = self.paso
        if paso and paso.objetivo_id == id_ and paso.mapa == self.mapa.id:
            self.guion.agregar(paso.guion())
        else:
            self.guion.agregar(self.cap.extras(self, id_))

    def _revisar_puertas(self):
        for p in self.mapa.puertas:
            if p.rect.colliderect(self.jugador.pies):
                permitido, msg = self._puerta_permitida(p)
                if permitido:
                    self.guion.agregar([Sonido("puerta", "[puerta]"), Fundido(True, 0.25),
                                        IrA(p.destino, p.spawn), Fundido(False, 0.25)])
                else:
                    self.jugador.y -= 6 if p.rect.top > ALTO // 2 else -6
                    self.jugador.x -= 8 if p.rect.left > ANCHO // 2 else -8 if p.rect.right < 60 else 0
                    self.guion.agregar([P(msg)])
                return

    def _puerta_permitida(self, puerta):
        meta = self.paso.mapa if self.paso else None
        casa = ("cuarto", "sala")
        if puerta.destino in casa and self.mapa.id in casa:
            return True, ""
        if puerta.destino == "colegio":
            return (meta == "colegio"), "Todavía tengo cosas que hacer en la casa."
        if self.mapa.id == "colegio":
            return (meta != "colegio"), "Todavía no me puedo ir del colegio."
        return False, "No puedo ir por ahí."

    # ------------------------------------------------ ciclo
    def manejar_evento(self, e):
        from sin_filtro.estados.menus import EstadoAyuda, EstadoPausa
        if e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_p):
            self.juego.apilar(EstadoPausa(self.juego))
            return
        if e.type == pygame.KEYDOWN and e.key == pygame.K_h:
            self.juego.apilar(EstadoAyuda(self.juego))
            return
        if self.guion.activo:
            self.guion.manejar_evento(self, e)
        elif e.type == pygame.KEYDOWN and e.key in CONFIRMAR:
            self._interactuar()

    def actualizar(self, dt):
        self.t += dt
        self.glitch = max(0.0, self.glitch - dt)
        self.flash = max(0.0, self.flash - dt)
        for em in self.emotes:
            em[2] += dt
        self.emotes = [em for em in self.emotes if em[2] < 1.6]
        self.jugador.actualizar(dt)
        for n in self.npcs.values():
            n.actualizar(dt)
        if self.guion.activo:
            if type(self.guion.actual).__name__ != "Mover":
                self.jugador.caminando = False
            self.guion.actualizar(self, dt)
            return
        teclas = pygame.key.get_pressed()
        dx = (teclas[pygame.K_d] or teclas[pygame.K_RIGHT]) - (teclas[pygame.K_a] or teclas[pygame.K_LEFT])
        dy = (teclas[pygame.K_s] or teclas[pygame.K_DOWN]) - (teclas[pygame.K_w] or teclas[pygame.K_UP])
        self.jugador.mover(dx, dy, dt, self.colisiona)
        self._revisar_puertas()

    # ------------------------------------------------ dibujo
    def dibujar(self, sup):
        d, pal = self.dibujo, self.paleta
        self.mapa.dibujar_fondo(sup, self.t, self)
        entidades = [self.jugador] + list(self.npcs.values())
        for ent in sorted(entidades, key=lambda p: p.y):
            ent.dibujar(sup, d)
        self.mapa.dibujar_frente(sup, self.t, self)
        if self.historia["algo"] >= 60 and not self.guion.activo:
            d.algo(sup, self.jugador.x + 34, self.jugador.y - 70, self.t, 0.7, self.historia["algo"] / 100)
        for quien, tipo, tt in self.emotes:
            p = self.personaje(quien)
            if p:
                d.burbuja(sup, p.x, p.y - 64 * p.ap.escala, tipo, tt)
        if not self.guion.activo:
            cercano = self._cercano()
            if cercano:
                tipo, id_, nombre = cercano
                txt = f"E: {'Hablar con ' if tipo == 'npc' else ''}{nombre}"
                w = d.f["peq"].size(txt)[0] + 20
                r = pygame.Rect(0, 0, w, 28)
                r.midbottom = (self.jugador.x, self.jugador.y - 66)
                pygame.draw.rect(sup, pal["panel"], r, border_radius=8)
                pygame.draw.rect(sup, pal["acento"], r, 2, border_radius=8)
                d.texto(sup, txt, r.center, pal["texto"], "peq", "center")
        self._hud(sup)
        if self.glitch > 0:
            self._efecto_glitch(sup)
        if self.flash > 0:
            capa = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
            capa.fill((255, 255, 255, int(255 * min(1, self.flash / 0.3))))
            sup.blit(capa, (0, 0))
        if self.fade > 0:
            capa = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
            capa.fill((8, 6, 16, int(self.fade)))
            sup.blit(capa, (0, 0))
        self.guion.dibujar(self, sup)

    def _hud(self, sup):
        d, pal = self.dibujo, self.paleta
        pygame.draw.rect(sup, pal["panel"], (0, 0, ANCHO, HUD))
        d.texto(sup, f"{self.cap.dia} · {self.mapa.nombre}", (12, HUD // 2), pal["suave"], "peq", "midleft")
        if self.paso and self.paso.objetivo and not self.guion.activo:
            d.texto(sup, "Objetivo: " + self.paso.objetivo, (ANCHO // 2 + 40, HUD // 2), pal["acento"], "peq", "center")
        # espejito (autoestima) y ojo de Algo: sin números, solo visual
        a = self.historia["autoestima"] / 100
        pygame.draw.ellipse(sup, (200, 200, 210), (ANCHO - 84, 5, 20, 26), 2)
        brillo = pygame.Surface((16, 22), pygame.SRCALPHA)
        pygame.draw.ellipse(brillo, (255, 230, 150, int(40 + 200 * a)), brillo.get_rect())
        sup.blit(brillo, (ANCHO - 82, 7))
        d.algo(sup, ANCHO - 30, HUD // 2, self.t, 0.35 + 0.35 * self.historia["algo"] / 100, 0)

    def _efecto_glitch(self, sup):
        copia = sup.copy()
        for _ in range(6):
            y = random.randint(0, ALTO - 20)
            h = random.randint(4, 24)
            dx = random.randint(-18, 18)
            sup.blit(copia, (dx, y), (0, y, ANCHO, h))
        tinte = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        tinte.fill((255, 0, 150, 28) if random.random() < 0.5 else (0, 220, 255, 28))
        sup.blit(tinte, (0, 0))
