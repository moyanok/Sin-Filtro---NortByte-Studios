"""Patrón State: cada pantalla del juego es un estado con la misma interfaz."""
from abc import ABC, abstractmethod


class Estado(ABC):
    transparente = False

    def __init__(self, juego):
        self.juego = juego

    def al_entrar(self):
        pass

    @abstractmethod
    def manejar_evento(self, e): ...

    def actualizar(self, dt):
        pass

    @abstractmethod
    def dibujar(self, sup): ...
