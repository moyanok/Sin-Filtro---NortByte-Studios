"""Escenas animadas: tarjeta de cada día, el espejo y los finales."""
import math
import random

import pygame

from sin_filtro import eventos as ev
from sin_filtro.acciones import CONFIRMAR, es_confirmar
from sin_filtro.config import ALTO, ANCHO
from sin_filtro.estados.base import Estado
from sin_filtro.historia import ETIQUETAS_DECISION


class EstadoTarjeta(Estado):
    """Tarjeta animada de inicio de capítulo: amanece mientras aparece el día."""

    def __init__(self, juego, dia, titulo, momento, al_terminar):
        super().__init__(juego)
        self.dia, self.titulo, self.momento, self.al_terminar = dia, titulo, momento, al_terminar
        self.t = 0.0

    def manejar_evento(self, e):
        if es_confirmar(e) and self.t > 0.8:
            self._fin()

    def _fin(self):
        self.juego.desapilar()
        self.al_terminar()

    def actualizar(self, dt):
        self.t += dt
        if self.t > 3.6:
            self._fin()

    def dibujar(self, sup):
        k = min(1, self.t / 2.5)
        for y in range(0, ALTO, 6):
            f = y / ALTO
            col = (int(30 + 200 * k * (1 - f) + 20), int(20 + 120 * k * (1 - f) + 10), int(70 + 90 * k * (1 - f)))
            sup.fill(col, (0, y, ANCHO, 6))
        sol_y = ALTO + 60 - 300 * k
        pygame.draw.circle(sup, (255, 210, 110), (ANCHO // 2, int(sol_y)), 70)
        pygame.draw.rect(sup, (20, 18, 40), (0, ALTO - 130, ANCHO, 130))
        for i, x in enumerate(range(0, ANCHO, 80)):
            h = 60 + (i * 37) % 70
            pygame.draw.rect(sup, (30, 26, 56), (x, ALTO - 130 - h, 70, h))
            for wy in range(ALTO - 120 - h, ALTO - 140, 18):
                if (x + wy) % 3:
                    pygame.draw.rect(sup, (255, 220, 120) if k < 0.6 else (60, 55, 90), (x + 12, wy, 10, 8))
        d = self.juego.dibujo
        alfa = min(255, int(self.t * 400))
        s1 = d.f["enorme"].render(self.dia.upper(), True, (255, 255, 255))
        s1.set_alpha(alfa)
        sup.blit(s1, s1.get_rect(center=(ANCHO // 2, 190)))
        s2 = d.f["grande"].render(self.titulo, True, (255, 230, 170))
        s2.set_alpha(max(0, alfa - 120))
        sup.blit(s2, s2.get_rect(center=(ANCHO // 2, 270)))


class EstadoEspejo(Estado):
    """El espejo: el reflejo de Vale cambia según cómo se siente (sin números ni barras)."""

    BAJA = ["Todas se ven mejor que yo.", "Si me viera como Cami...", "Mejor me pongo el saco, aunque haga calor."]
    MEDIA = ["Hoy me veo... normal. Y normal está bien.", "Algunos días es más fácil que otros.", "Soy más que lo que se ve."]
    ALTA = ["Esta soy yo. Y me cae bien.", "Mis piernas me sirven para bailar.", "No necesito un filtro para estar aquí."]

    def __init__(self, juego, historia, ap, al_terminar):
        super().__init__(juego)
        self.a = historia["autoestima"]
        self.ap = ap
        self.al_terminar = al_terminar
        self.t = 0.0
        frases = self.BAJA if self.a < 45 else self.MEDIA if self.a < 65 else self.ALTA
        self.frases = frases
        juego.bus.publicar(ev.SONIDO, nombre="triste" if self.a < 45 else "bien",
                           subtitulo="[música suave]")

    def manejar_evento(self, e):
        if es_confirmar(e) and self.t > 2.0:
            self.juego.desapilar()
            self.al_terminar()

    def actualizar(self, dt):
        self.t += dt

    def dibujar(self, sup):
        d = self.juego.dibujo
        sup.fill((40, 30, 50))
        marco = pygame.Rect(0, 0, 300, 440)
        marco.center = (ANCHO // 2, ALTO // 2 + 10)
        pygame.draw.rect(sup, (210, 175, 110), marco, border_radius=150)
        vidrio = marco.inflate(-28, -28)
        reflejo = pygame.Surface(vidrio.size, pygame.SRCALPHA)
        bajo = self.a < 45
        reflejo.fill((150, 165, 190) if bajo else (205, 230, 245))
        d.personaje(reflejo, vidrio.w // 2, vidrio.h + 30, self.ap, "abajo", self.t, False, 3.8,
                    "triste" if bajo else "feliz" if self.a >= 65 else "normal")
        if bajo:  # vidrio distorsionado: así ve Vale su reflejo cuando está mal
            amp = (45 - self.a) / 3 + 4
            onda = pygame.Surface(vidrio.size, pygame.SRCALPHA)
            for y in range(0, vidrio.h, 4):
                dx = math.sin(y / 18 + self.t * 2.4) * amp
                onda.blit(reflejo, (dx, y), (0, y, vidrio.w, 4))
            reflejo = onda
            gris = pygame.Surface(vidrio.size, pygame.SRCALPHA)
            gris.fill((40, 40, 60, 90))
            reflejo.blit(gris, (0, 0))
        mascara = pygame.Surface(vidrio.size, pygame.SRCALPHA)
        pygame.draw.rect(mascara, (255, 255, 255, 255), mascara.get_rect(), border_radius=136)
        reflejo.blit(mascara, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        sup.blit(reflejo, vidrio.topleft)
        if bajo:
            for i in range(3):
                x0 = vidrio.x + 40 + i * 70
                pygame.draw.lines(sup, (230, 230, 240), False, [(x0, vidrio.y + 60), (x0 + 15, vidrio.y + 100),
                                                               (x0 - 5, vidrio.y + 140), (x0 + 10, vidrio.y + 170)], 2)
        elif self.a >= 65:
            for i in range(8):
                ang = self.t * 1.5 + i * 0.8
                x = vidrio.centerx + math.cos(ang) * 120
                y = vidrio.centery + math.sin(ang * 1.3) * 170
                pygame.draw.circle(sup, (255, 240, 170), (x, y), 3 + (i % 2) * 2)
        for i, frase in enumerate(self.frases):
            aparece = self.t - 0.5 - i * 0.9
            if aparece <= 0:
                continue
            col = (200, 190, 230) if bajo else (255, 240, 200)
            capa = pygame.Surface((300, 120), pygame.SRCALPHA)
            d.parrafo(capa, frase, 0, 0, 280, col, d.cursiva, centrado=True)
            capa.set_alpha(min(255, int(aparece * 300)))
            x = 20 if i % 2 == 0 else ANCHO - 310
            sup.blit(capa, (x, 110 + i * 120))
        if self.t > 2.0 and int(self.t * 2.5) % 2 == 0:
            d.texto(sup, "E / Espacio para seguir", (ANCHO // 2, ALTO - 10), (255, 255, 255), "mini", "midbottom")


class EstadoFinal(Estado):
    """Final animado según las decisiones, resumen del camino y pantalla de ayuda."""

    TEXTOS = {
        "sin_filtro": ("FINAL: SIN FILTRO",
                       "Vale volvió a bailar. No ganó el primer puesto, pero ganó algo más importante: "
                       "dejó de pedirle permiso al espejo."),
        "en_pausa": ("FINAL: EN PAUSA",
                     "Vale todavía se compara a veces. Pero ahora sabe reconocer cuándo es Algo el que habla, y no ella."),
        "atrapada": ("FINAL: ATRAPADA",
                     "Vale sigue en su cuarto, con el celular en la mano. Pero esta historia no tiene por qué "
                     "terminar así. Puedes volver a intentarlo."),
    }

    def __init__(self, juego, historia, ap, reparto):
        super().__init__(juego)
        self.historia = historia
        self.final = historia.calcular_final()
        self.ap, self.reparto = ap, reparto
        self.t = 0.0
        self.pagina = 0
        juego.bus.publicar(ev.SONIDO, nombre="logro" if self.final != "atrapada" else "triste",
                           subtitulo="[música de final]")

    def manejar_evento(self, e):
        from sin_filtro.estados.menus import EstadoTitulo
        if es_confirmar(e) and self.t > 1.2:
            self.pagina += 1
            self.t = 0.0
            if self.pagina > 2:
                self.juego.reiniciar_a(EstadoTitulo(self.juego))

    def actualizar(self, dt):
        self.t += dt

    def dibujar(self, sup):
        [self._escena, self._resumen, self._ayuda][min(self.pagina, 2)](sup)
        if self.t > 1.2 and int(self.t * 2.5) % 2 == 0:
            self.juego.dibujo.texto(sup, "E / Espacio >", (ANCHO - 20, ALTO - 12), (255, 255, 255), "peq", "bottomright")

    def _escena(self, sup):
        d, t = self.juego.dibujo, self.t
        if self.final == "sin_filtro":  # Vale bailando en el concurso
            sup.fill((30, 20, 50))
            luz = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
            pygame.draw.polygon(luz, (255, 240, 180, 60), [(ANCHO // 2 - 30, 0), (ANCHO // 2 + 30, 0), (ANCHO // 2 + 160, 380), (ANCHO // 2 - 160, 380)])
            sup.blit(luz, (0, 0))
            pygame.draw.rect(sup, (110, 70, 50), (0, 330, ANCHO, 60))
            salto = abs(math.sin(t * 5)) * 18
            d.personaje(sup, ANCHO // 2, 350 - salto, self.ap, "izq" if int(t * 2) % 2 else "der", t * 1.5, True, 2.4, "feliz")
            for i in range(9):
                x = 80 + i * 100
                d.personaje(sup, x, ALTO + 40 + math.sin(t * 6 + i) * 4, self.reparto[["sofi", "mateo", "laura", "mama", "andres"][i % 5]].ap, "arriba", t, False, 1.6)
        elif self.final == "en_pausa":  # atardecer en la playa con Sofi
            for y in range(0, 300, 6):
                sup.fill((250 - y // 3, 150 - y // 4, 110 + y // 6), (0, y, ANCHO, 6))
            pygame.draw.circle(sup, (255, 210, 120), (ANCHO // 2, 290), 60)
            sup.fill((90, 80, 140), (0, 290, ANCHO, 80))
            sup.fill((230, 200, 150), (0, 370, ANCHO, 200))
            d.personaje(sup, ANCHO // 2 - 30, 430, self.ap, "arriba", t, False, 2.0)
            d.personaje(sup, ANCHO // 2 + 30, 430, self.reparto["sofi"].ap, "arriba", t, False, 2.0)
        else:  # cuarto oscuro, luz del celular; llega un mensaje de Sofi
            sup.fill((12, 10, 26))
            brillo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
            pygame.draw.circle(brillo, (120, 160, 255, 50), (ANCHO // 2, 330), 140)
            sup.blit(brillo, (0, 0))
            d.personaje(sup, ANCHO // 2, 420, self.ap, "abajo", t, False, 2.4, "triste")
            pygame.draw.rect(sup, (150, 190, 255), (ANCHO // 2 - 10, 340, 20, 30), border_radius=4)
            if t > 1.5:
                r = pygame.Rect(ANCHO // 2 + 60, 280, 230, 54)
                pygame.draw.rect(sup, (255, 255, 255), r, border_radius=12)
                d.texto(sup, "Sofi: Te extrañé hoy. ¿Hablamos?", (r.x + 12, r.centery), (30, 30, 40), "mini", "midleft")
        titulo, texto = self.TEXTOS[self.final]
        caja = pygame.Rect(40, 24, ANCHO - 80, 130)
        d.panel(sup, caja, self.juego.paleta)
        d.texto(sup, titulo, (caja.centerx, caja.y + 30), self.juego.paleta["acento"], "grande", "center")
        d.parrafo(sup, texto, caja.x + 30, caja.y + 58, caja.w - 60, self.juego.paleta["texto"], "normal", centrado=True)

    def _resumen(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        sup.fill((26, 22, 44))
        d.texto(sup, "Tu camino en la historia", (ANCHO // 2, 50), pal["acento"], "grande", "center")
        y = 100
        for id_, opcion in self.historia.decisiones:
            etiqueta = ETIQUETAS_DECISION.get(id_, id_)
            d.texto(sup, etiqueta + ":", (80, y), pal["suave"], "peq")
            d.texto(sup, opcion.strip('"'), (340, y), pal["texto"], "peq")
            y += 30
        arbol = self.historia.arbol
        d.texto(sup, f"Caminos distintos descubiertos: {arbol.contar_hojas()}   ·   Decisiones en este camino: {len(self.historia.decisiones)}",
                (ANCHO // 2, ALTO - 50), pal["texto"], "peq", "center")

    def _ayuda(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        sup.fill((26, 22, 44))
        d.corazon(sup, ANCHO // 2, 90, 26, (235, 90, 120))
        d.texto(sup, "Si te sentiste identificado o identificada con Vale", (ANCHO // 2, 160), pal["texto"], "grande", "center")
        lineas = [
            "Lo que ves en redes casi nunca es real. Tu valor no depende de un filtro ni de los likes.",
            "Hablar ayuda: con un amigo, con tu familia, con un profe o con la psicóloga del colegio.",
            "En Colombia: Línea 192, opción 4 (orientación en salud mental, gratuita).",
            "En varias ciudades: Línea 106. En una emergencia: 123.",
        ]
        y = 220
        for l in lineas:
            y = d.parrafo(sup, l, 100, y, ANCHO - 200, pal["texto"], "normal", centrado=True) + 14
        d.texto(sup, "Gracias por jugar Sin Filtro · NorteByte Studios", (ANCHO // 2, ALTO - 60), pal["suave"], "peq", "center")
