"""Ejecutor de cinemáticas (patrón Command). Usa una Pila de Colas: cada decisión empuja una
nueva cola de acciones (la rama elegida) que se ejecuta antes de continuar con la anterior."""
from sin_filtro.estructuras import Cola, Pila


class Guion:
    def __init__(self):
        self.pila = Pila()
        self.actual = None

    def agregar(self, acciones):
        cola = Cola()
        for a in acciones:
            cola.encolar(a)
        if len(cola):
            self.pila.push(cola)

    insertar = agregar

    def limpiar(self):
        self.pila = Pila()
        self.actual = None

    @property
    def activo(self):
        if self.actual is not None:
            return True
        return any(not c.esta_vacia() for c in self.pila)

    def _siguiente(self, ctx):
        while not self.pila.esta_vacia():
            tope = self.pila.peek()
            if tope.esta_vacia():
                self.pila.pop()
                continue
            self.actual = tope.desencolar()
            self.actual.iniciar(ctx)
            return True
        return False

    def actualizar(self, ctx, dt):
        for _ in range(60):  # procesa varias acciones instantáneas en el mismo cuadro
            if self.actual is None and not self._siguiente(ctx):
                return
            if self.actual is None:
                return
            accion = self.actual
            if accion.actualizar(ctx, dt):
                if self.actual is accion:
                    self.actual = None
                dt = 0
            else:
                return

    def manejar_evento(self, ctx, e):
        if self.actual:
            self.actual.manejar_evento(ctx, e)

    def dibujar(self, ctx, sup):
        if self.actual:
            self.actual.dibujar(ctx, sup)
