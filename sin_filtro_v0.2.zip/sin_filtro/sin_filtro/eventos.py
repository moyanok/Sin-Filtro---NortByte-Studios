"""Patrón Observer: bus de eventos."""
from collections import defaultdict

SONIDO = "sonido"            # datos: nombre, subtitulo
STATS = "stats"              # cambió un indicador de la historia
DECISION = "decision"


class EventBus:
    def __init__(self):
        self._subs = defaultdict(list)

    def suscribir(self, evento, cb):
        if cb not in self._subs[evento]:
            self._subs[evento].append(cb)

    def publicar(self, evento, **datos):
        for cb in list(self._subs[evento]):
            cb(**datos)
