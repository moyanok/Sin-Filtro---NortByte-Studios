"""Observador de sonido: sintetiza efectos sin archivos externos. Si no hay audio, el juego sigue."""
import math
import random
from array import array

import pygame

from sin_filtro import eventos as ev


class GestorSonido:
    NOTAS = {
        "notificacion": [(880, 0.06), (0, 0.04), (1175, 0.08)],
        "blip": [(620, 0.018)],
        "elegir": [(523, 0.05), (784, 0.08)],
        "mover": [(480, 0.025)],
        "logro": [(523, 0.08), (659, 0.08), (784, 0.08), (1046, 0.2)],
        "triste": [(392, 0.15), (330, 0.15), (262, 0.25)],
        "puerta": [(180, 0.06), (140, 0.08)],
        "foto": [(1500, 0.02), (0, 0.03), (900, 0.05)],
        "bien": [(660, 0.06), (880, 0.08)],
        "mal": [(220, 0.1), (170, 0.12)],
    }

    def __init__(self, bus, ajustes):
        self.ajustes = ajustes
        self.sonidos = {}
        self.disponible = False
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=1)
            self.sonidos = {k: self._tono(v) for k, v in self.NOTAS.items()}
            self.sonidos["glitch"] = self._ruido(0.25)
            self.disponible = True
        except pygame.error:
            self.disponible = False
        bus.suscribir(ev.SONIDO, self._al_sonar)

    @staticmethod
    def _tono(notas, tasa=22050, vol=0.22):
        m = array("h")
        for f, d in notas:
            n = int(tasa * d)
            for i in range(n):
                env = min(1.0, (n - i) / (0.35 * n + 1))
                m.append(0 if f == 0 else int(32767 * vol * env * math.sin(2 * math.pi * f * i / tasa)))
        return pygame.mixer.Sound(buffer=m.tobytes())

    @staticmethod
    def _ruido(d, tasa=22050, vol=0.12):
        rnd = random.Random(7)
        m = array("h", (int(32767 * vol * rnd.uniform(-1, 1) * (1 if (i // 400) % 2 else 0.3)) for i in range(int(tasa * d))))
        return pygame.mixer.Sound(buffer=m.tobytes())

    def _al_sonar(self, nombre, **_):
        if self.disponible and self.ajustes.sonido and nombre in self.sonidos:
            self.sonidos[nombre].play()
