"""Estado de la historia: indicadores internos, banderas, resultados y árbol de decisiones."""
from sin_filtro import eventos as ev
from sin_filtro.estructuras import ArbolDecisiones

ETIQUETAS_DECISION = {
    "desayuno": "Lunes, desayuno",
    "invitacion": "Invitación de Sofi",
    "comentarios": "Comentarios de la foto",
    "contar_sofi": "Hablar con Sofi",
    "baile_pensar": "Concurso de baile",
    "dejar_seguir": "Después del video de Cami",
    "hablar_mama": "Conversación con mamá",
    "consejo_andres": "Consejo para Andrés",
    "inscripcion": "Inscripción al concurso",
    "ir_playa": "El sábado",
    "foto_final": "La foto del cumpleaños",
    "segunda_oportunidad": "Segunda oportunidad",
}


class GestorHistoria:
    INICIAL = {"autoestima": 50, "algo": 45, "sofi": 60, "mama": 50}

    def __init__(self, bus):
        self.bus = bus
        self.arbol = ArbolDecisiones()
        self.reiniciar()

    def reiniciar(self):
        self.stats = dict(self.INICIAL)
        self.flags = set()
        self.resultados = {}
        self.decisiones = []
        self.capitulo = 1
        self.arbol.nuevo_recorrido()

    def __getitem__(self, k):
        return self.stats[k]

    def cambiar(self, **deltas):
        for k, d in deltas.items():
            self.stats[k] = max(0, min(100, self.stats[k] + d))
        self.bus.publicar(ev.STATS, stats=dict(self.stats))

    def poner(self, flag):
        self.flags.add(flag)

    def tiene(self, flag):
        return flag in self.flags

    def registrar_decision(self, id_, opcion):
        self.decisiones.append((id_, opcion))
        self.arbol.registrar(id_, opcion)
        self.bus.publicar(ev.DECISION, id=id_, opcion=opcion)

    @property
    def puntaje(self):
        s = self.stats
        return s["autoestima"] - s["algo"] + (s["sofi"] + s["mama"] - 100) * 0.25

    def calcular_final(self):
        if not self.tiene("fue_playa") or self.puntaje < -5:
            return "atrapada"
        if self.puntaje >= 45:
            return "sin_filtro"
        return "en_pausa"
