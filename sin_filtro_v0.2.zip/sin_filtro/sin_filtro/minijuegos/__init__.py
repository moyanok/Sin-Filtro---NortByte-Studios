"""Fábrica de minijuegos (patrón Factory)."""
from sin_filtro.minijuegos.detecta import MinijuegoDetecta
from sin_filtro.minijuegos.editor import MinijuegoEditor
from sin_filtro.minijuegos.scroll import MinijuegoScroll

_REGISTRO = {"editor": MinijuegoEditor, "detecta": MinijuegoDetecta, "scroll": MinijuegoScroll}


def crear_minijuego(nombre, juego, historia, ap_vale, al_terminar):
    return _REGISTRO[nombre](juego, historia, ap_vale, al_terminar)
