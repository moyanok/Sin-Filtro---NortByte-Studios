"""Minijuego 'Sal del feed': de noche, esquivar lo que quita el sueño y recoger lo que ayuda a dormir."""
import pygame

from sin_filtro.config import ALTO, ANCHO
from sin_filtro.minijuegos.base import Minijuego


class Item:
    def __init__(self, x, vel, texto, bueno):
        self.x, self.y, self.vel, self.texto, self.bueno = x, 40.0, vel, texto, bueno

    @property
    def rect(self):
        return pygame.Rect(int(self.x - 18), int(self.y - 18), 36, 36)


class MinijuegoScroll(Minijuego):
    nombre = "scroll"
    titulo = "Sal del feed"
    instrucciones = ("Son las 11 p.m. y Algo no deja dormir a Vale. Muévete con A/D o las flechas. Recoge lo que "
                     "ayuda a dormir (círculos) y esquiva lo que la engancha (triángulos). Llena la luna para dormir.")
    duracion = 30
    BUENOS = ["Modo avión", "Música tranqui", "Mensaje de Sofi", "Libro", "Respirar"]
    MALOS = ["Un video más", "Comparación", "Comentario feo", "Notificación", "Reto viral"]
    CARRIL = pygame.Rect(300, 30, 360, 500)

    def __init__(self, *a):
        super().__init__(*a)
        self.x = float(self.CARRIL.centerx)
        self.items = []
        self.t_spawn = 0.0
        self.sueno = 40.0

    def manejar_juego(self, e):
        pass

    def actualizar_juego(self, dt):
        teclas = pygame.key.get_pressed()
        dx = (teclas[pygame.K_d] or teclas[pygame.K_RIGHT]) - (teclas[pygame.K_a] or teclas[pygame.K_LEFT])
        if pygame.mouse.get_pressed()[0]:
            mx = pygame.mouse.get_pos()[0]
            dx = 0 if abs(mx - self.x) < 6 else (1 if mx > self.x else -1)
        self.x = max(self.CARRIL.left + 24, min(self.CARRIL.right - 24, self.x + dx * 330 * dt))
        self.t_spawn -= dt
        if self.t_spawn <= 0:
            bueno = self.rng.random() < 0.45
            txt = self.rng.choice(self.BUENOS if bueno else self.MALOS)
            self.items.append(Item(self.rng.randint(self.CARRIL.left + 30, self.CARRIL.right - 30),
                                   self.rng.uniform(150, 220) + self.t * 3, txt, bueno))
            self.t_spawn = max(0.4, 0.85 - self.t * 0.012)
        jug = pygame.Rect(int(self.x - 22), self.CARRIL.bottom - 70, 44, 44)
        for it in self.items:
            it.y += it.vel * dt
            if it.rect.colliderect(jug):
                it.y = 9999
                self.sueno += 9 if it.bueno else -11
                self.juego.bus.publicar("sonido", nombre="bien" if it.bueno else "mal",
                                        subtitulo="[campanita]" if it.bueno else "[zumbido]")
        self.items = [i for i in self.items if i.y < self.CARRIL.bottom + 30]
        self.sueno = max(0.0, min(100.0, self.sueno))
        if self.sueno >= 100:
            self.terminar()

    def dibujar_juego(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        sup.fill((10, 12, 34))
        pygame.draw.rect(sup, (15, 15, 22), self.CARRIL.inflate(24, 24), border_radius=30)
        pygame.draw.rect(sup, (28, 30, 60), self.CARRIL, border_radius=20)
        for it in self.items:
            if it.bueno:
                pygame.draw.circle(sup, pal["bien"], (int(it.x), int(it.y)), 18)
            else:
                pygame.draw.polygon(sup, pal["mal"], [(it.x, it.y - 20), (it.x - 20, it.y + 16), (it.x + 20, it.y + 16)])
            d.texto(sup, it.texto, (it.x, it.y + 22), (240, 240, 250), "mini", "midtop")
        d.personaje(sup, self.x, self.CARRIL.bottom - 18, self.ap, "arriba", self.t, False, 1.0)
        # luna de sueño (se llena)
        cx, cy, r = 160, 200, 70
        pygame.draw.circle(sup, (60, 60, 90), (cx, cy), r)
        alto = int(2 * r * self.sueno / 100)
        luna = pygame.Surface((2 * r, 2 * r), pygame.SRCALPHA)
        pygame.draw.circle(luna, (250, 240, 190), (r, r), r)
        sup.blit(luna, (cx - r, cy + r - alto), (0, 2 * r - alto, 2 * r, alto))
        d.texto(sup, "Sueño", (cx, cy + r + 14), pal["texto"], "normal", "midtop")
        d.algo(sup, 800, 180, self.t, 1.6, 0.8)
        d.parrafo(sup, "\"Uno más... uno más...\"", 700, 260, 200, pal["algo"], "peq", centrado=True)

    def calcular_resultado(self):
        return {"durmio": self.sueno >= 70, "sueno": int(self.sueno)}

    def aplicar_efectos(self):
        if self.sueno >= 70:
            self.historia.cambiar(autoestima=4, algo=-6)
        else:
            self.historia.cambiar(autoestima=-4, algo=8)

    def texto_resultado(self):
        if self.sueno >= 70:
            return "Vale soltó el celular y se durmió. Mañana va a amanecer con más energía."
        return "Algo ganó esta noche: Vale se quedó scrolleando hasta la madrugada."
