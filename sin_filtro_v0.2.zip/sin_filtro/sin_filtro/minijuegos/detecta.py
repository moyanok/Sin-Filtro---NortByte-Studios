"""Minijuego 'Detecta el filtro': encontrar las pistas de edición en la foto 'perfecta' de Cami.
Las pistas que aparecen se eligen al azar en cada partida (componente aleatorio)."""
import math

import pygame

from sin_filtro.acciones import CONFIRMAR
from sin_filtro.config import ALTO, ANCHO
from sin_filtro.minijuegos.base import Minijuego
from sin_filtro.personajes import AP_CAMI


class MinijuegoDetecta(Minijuego):
    nombre = "detecta"
    titulo = "Detecta el filtro"
    instrucciones = ("Esta foto de Cami tiene 4 pistas de edición escondidas. Mueve la lupa con W A S D o el mouse "
                     "y presiona E (o clic) donde veas algo raro. Tienes 35 segundos.")
    duracion = 35
    FOTO = pygame.Rect(200, 60, 560, 420)
    PISTAS = {
        "baranda": (pygame.Rect(250, 250, 80, 90), "Baranda torcida: el editor dobla lo que está cerca del cuerpo."),
        "horizonte": (pygame.Rect(400, 170, 160, 50), "Horizonte curvo: el mar no se dobla en la vida real."),
        "nube": (pygame.Rect(620, 80, 120, 60), "Nube clonada: copiaron y pegaron partes de la foto."),
        "piel": (pygame.Rect(430, 220, 100, 80), "Piel de plástico: sin poros, sin sombras, sin textura."),
        "sombra": (pygame.Rect(470, 420, 160, 50), "Sombra que no cuadra: el cuerpo cambió y la sombra no."),
        "baldosas": (pygame.Rect(560, 330, 120, 90), "Baldosas onduladas: deformaron la cintura y arrastraron el piso."),
    }

    def __init__(self, *a):
        super().__init__(*a)
        self.activas = self.rng.sample(list(self.PISTAS), 4)
        self.encontradas = []
        self.lupa = [ANCHO // 2, ALTO // 2]
        self.errores = 0
        self.mensaje, self.t_msg = "", 0.0

    def manejar_juego(self, e):
        if e.type == pygame.KEYDOWN and e.key in CONFIRMAR:
            self._marcar(self.lupa)
        elif e.type == pygame.MOUSEMOTION:
            self.lupa = list(e.pos)
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.lupa = list(e.pos)
            self._marcar(e.pos)

    def _marcar(self, pos):
        for p in self.activas:
            if p not in self.encontradas and self.PISTAS[p][0].inflate(16, 16).collidepoint(pos):
                self.encontradas.append(p)
                self.mensaje, self.t_msg = self.PISTAS[p][1], 3.0
                self.juego.bus.publicar("sonido", nombre="bien", subtitulo="[pista encontrada]")
                if len(self.encontradas) == len(self.activas):
                    self.terminar()
                return
        self.errores += 1
        self.t += 1.5  # equivocarse cuesta tiempo
        self.mensaje, self.t_msg = "Ahí no hay nada raro... (-1.5 s)", 1.2
        self.juego.bus.publicar("sonido", nombre="mal", subtitulo="[error]")

    def actualizar_juego(self, dt):
        import pygame as pg
        teclas = pg.key.get_pressed()
        v = 300 * dt
        self.lupa[0] += ((teclas[pg.K_d] or teclas[pg.K_RIGHT]) - (teclas[pg.K_a] or teclas[pg.K_LEFT])) * v
        self.lupa[1] += ((teclas[pg.K_s] or teclas[pg.K_DOWN]) - (teclas[pg.K_w] or teclas[pg.K_UP])) * v
        self.lupa[0] = max(self.FOTO.left, min(self.FOTO.right, self.lupa[0]))
        self.lupa[1] = max(self.FOTO.top, min(self.FOTO.bottom, self.lupa[1]))
        self.t_msg = max(0, self.t_msg - dt)

    def dibujar_juego(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        sup.fill((22, 18, 36))
        f = self.FOTO
        act = set(self.activas)
        sup.fill((160, 215, 245), (f.x, f.y, f.w, 130))
        # nubes
        for cx in (300, 470):
            for dx in (0, 22, 44):
                pygame.draw.circle(sup, (255, 255, 255), (cx + dx, 110 + (dx == 22) * -8), 18)
        if "nube" in act:
            for dx in (0, 22, 44):
                pygame.draw.circle(sup, (255, 255, 255), (650 + dx, 110 + (dx == 22) * -8), 18)
        # mar y horizonte
        sup.fill((60, 150, 210), (f.x, f.y + 130, f.w, 70))
        pts = []
        for x in range(f.x, f.right + 1, 8):
            curva = -18 * max(0, 1 - abs(x - 480) / 70) if "horizonte" in act else 0
            pts.append((x, f.y + 130 + curva))
        pygame.draw.lines(sup, (40, 110, 170), False, pts, 4)
        # piso de baldosas
        sup.fill((235, 225, 210), (f.x, f.y + 200, f.w, f.h - 200))
        for i in range(8):
            y = f.y + 220 + i * 26
            pts = []
            for x in range(f.x, f.right + 1, 8):
                onda = 10 * math.sin((x - 560) / 12) if "baldosas" in act and 560 < x < 680 and 330 < y < 420 else 0
                pts.append((x, y + onda))
            pygame.draw.lines(sup, (200, 190, 175), False, pts, 2)
        # baranda
        for i in range(10):
            x = f.x + 30 + i * 16
            if "baranda" in act and 250 < x < 330:
                pygame.draw.lines(sup, (120, 90, 70), False, [(x, 260), (x + 10, 295), (x, 330)], 4)
            else:
                pygame.draw.line(sup, (120, 90, 70), (x, 260), (x, 330), 4)
        pygame.draw.line(sup, (120, 90, 70), (f.x + 20, 260), (f.x + 200, 260), 6)
        # sombra
        sx = 600 if "sombra" in act else 450
        pygame.draw.ellipse(sup, (190, 180, 165), (sx, 430, 110, 24))
        # Cami
        d.personaje(sup, 480, 450, AP_CAMI, "abajo", 0, False, 3.0, "feliz")
        if "piel" in act:
            capa = pygame.Surface((120, 110), pygame.SRCALPHA)
            pygame.draw.ellipse(capa, (255, 235, 240, 120), capa.get_rect())
            sup.blit(capa, (420, 210))
        pygame.draw.rect(sup, (255, 255, 255), f, 4)
        d.texto(sup, "@cami.perfect", (f.x, f.y - 30), (230, 230, 240), "peq")
        for p in self.encontradas:
            pygame.draw.ellipse(sup, pal["bien"], self.PISTAS[p][0].inflate(14, 14), 4)
        d.texto(sup, f"Pistas: {len(self.encontradas)} / {len(self.activas)}", (20, 12), pal["texto"], "normal")
        if self.fase == "juego":
            x, y = map(int, self.lupa)
            pygame.draw.circle(sup, (255, 255, 255), (x, y), 26, 3)
            pygame.draw.line(sup, (255, 255, 255), (x + 18, y + 18), (x + 34, y + 34), 6)
        if self.t_msg > 0:
            caja = pygame.Rect(120, ALTO - 54, ANCHO - 240, 44)
            d.panel(sup, caja, pal)
            d.texto(sup, self.mensaje, caja.center, pal["texto"], "peq", "center")

    def calcular_resultado(self):
        return {"encontradas": len(self.encontradas), "total": len(self.activas)}

    def aplicar_efectos(self):
        n = len(self.encontradas)
        self.historia.cambiar(autoestima=3 * n, algo=-3 * n)

    def texto_resultado(self):
        n = len(self.encontradas)
        base = f"Encontraste {n} de {len(self.activas)} pistas. "
        return base + ("La foto 'perfecta' tenía más edición que realidad." if n >= 3
                       else "Las ediciones están hechas para que no las notes. Por eso parecen reales.")
