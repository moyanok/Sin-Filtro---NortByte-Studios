"""Patrón Template Method: todos los minijuegos siguen intro -> juego -> resultado.
Cada subclase solo define su lógica, su dibujo y sus efectos en la historia."""
from abc import abstractmethod

import pygame

from sin_filtro import eventos as ev
from sin_filtro.acciones import CONFIRMAR, es_confirmar
from sin_filtro.config import ALTO, ANCHO
from sin_filtro.estados.base import Estado


class Minijuego(Estado):
    nombre = ""
    titulo = ""
    instrucciones = ""
    duracion = None

    def __init__(self, juego, historia, ap_vale, al_terminar):
        super().__init__(juego)
        self.historia = historia
        self.ap = ap_vale
        self.al_terminar = al_terminar
        self.fase = "intro"
        self.t = 0.0
        self.t_fase = 0.0
        self.resultado = None
        self.rng = juego.rng if hasattr(juego, "rng") else __import__("random").Random()

    # --- plantilla ---
    def manejar_evento(self, e):
        if self.fase == "intro":
            if es_confirmar(e) and self.t_fase > 0.3:
                self.fase, self.t_fase = "juego", 0.0
        elif self.fase == "juego":
            self.manejar_juego(e)
        elif es_confirmar(e) and self.t_fase > 0.6:
            self.historia.resultados[self.nombre] = self.resultado
            self.juego.desapilar()
            self.al_terminar(self.resultado)

    def actualizar(self, dt):
        self.t_fase += dt
        if self.fase == "juego":
            self.t += dt
            self.actualizar_juego(dt)
            if self.duracion and self.t >= self.duracion:
                self.terminar()

    def terminar(self):
        if self.fase != "juego":
            return
        self.resultado = self.calcular_resultado()
        self.aplicar_efectos()
        self.fase, self.t_fase = "resultado", 0.0
        self.juego.bus.publicar(ev.SONIDO, nombre="logro", subtitulo="[fin del minijuego]")

    def dibujar(self, sup):
        self.dibujar_juego(sup)
        d, pal = self.juego.dibujo, self.juego.paleta
        if self.fase == "juego" and self.duracion:
            restante = max(0, self.duracion - self.t)
            d.texto(sup, f"Tiempo: {restante:0.0f} s", (ANCHO - 20, 12), pal["acento"], "normal", "topright")
        if self.fase in ("intro", "resultado"):
            velo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
            velo.fill((0, 0, 0, 160))
            sup.blit(velo, (0, 0))
            caja = pygame.Rect(150, 110, ANCHO - 300, 300)
            d.panel(sup, caja, pal)
            titulo = self.titulo if self.fase == "intro" else "Resultado"
            cuerpo = self.instrucciones if self.fase == "intro" else self.texto_resultado()
            d.texto(sup, titulo, (caja.centerx, caja.y + 40), pal["acento"], "grande", "center")
            d.parrafo(sup, cuerpo, caja.x + 36, caja.y + 86, caja.w - 72, pal["texto"], "normal", 6, centrado=True)
            d.texto(sup, "E / Espacio para " + ("empezar" if self.fase == "intro" else "continuar"),
                    (caja.centerx, caja.bottom - 26), pal["suave"], "peq", "center")

    # --- pasos que cambian en cada minijuego ---
    @abstractmethod
    def manejar_juego(self, e): ...

    @abstractmethod
    def actualizar_juego(self, dt): ...

    @abstractmethod
    def dibujar_juego(self, sup): ...

    @abstractmethod
    def calcular_resultado(self): ...

    @abstractmethod
    def aplicar_efectos(self): ...

    @abstractmethod
    def texto_resultado(self): ...
