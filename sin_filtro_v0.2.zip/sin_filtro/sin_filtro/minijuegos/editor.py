"""Minijuego 'Editor': Vale decide cuánto editar su foto. Algo predice más likes entre más edita."""
import pygame

from sin_filtro import eventos as ev
from sin_filtro.acciones import CONFIRMAR
from sin_filtro.config import ALTO, ANCHO
from sin_filtro.minijuegos.base import Minijuego


class MinijuegoEditor(Minijuego):
    nombre = "editor"
    titulo = "Editor de fotos"
    instrucciones = ("Algo le armó un editor a Vale. W/S para escoger una barra, A/D (o el mouse) para moverla. "
                     "Cuando quieras, presiona E para publicar. No hay respuesta correcta: tú decides.")
    BARRAS = ["Suavizar piel", "Afinar cara y cuerpo", "Filtro de brillo"]

    def __init__(self, *a):
        super().__init__(*a)
        self.valores = [0.0, 0.0, 0.0]
        self.sel = 0
        self.arrastrando = None
        self.base_likes = self.rng.randint(90, 160)

    @property
    def nivel(self):
        return sum(self.valores) / 3

    def _barra(self, i):
        return pygame.Rect(560, 200 + i * 90, 320, 14)

    def manejar_juego(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_w, pygame.K_UP):
                self.sel = (self.sel - 1) % 3
            elif e.key in (pygame.K_s, pygame.K_DOWN):
                self.sel = (self.sel + 1) % 3
            elif e.key in (pygame.K_a, pygame.K_LEFT):
                self.valores[self.sel] = max(0.0, self.valores[self.sel] - 0.1)
            elif e.key in (pygame.K_d, pygame.K_RIGHT):
                self.valores[self.sel] = min(1.0, self.valores[self.sel] + 0.1)
                self.juego.bus.publicar(ev.SONIDO, nombre="mover")
            elif e.key in CONFIRMAR:
                self.terminar()
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i in range(3):
                if self._barra(i).inflate(0, 30).collidepoint(e.pos):
                    self.sel, self.arrastrando = i, i
                    self._arrastrar(e.pos[0])
            if pygame.Rect(600, 470, 240, 46).collidepoint(e.pos):
                self.terminar()
        elif e.type == pygame.MOUSEBUTTONUP:
            self.arrastrando = None
        elif e.type == pygame.MOUSEMOTION and self.arrastrando is not None:
            self._arrastrar(e.pos[0])

    def _arrastrar(self, x):
        b = self._barra(self.arrastrando)
        self.valores[self.arrastrando] = max(0.0, min(1.0, (x - b.x) / b.w))

    def actualizar_juego(self, dt):
        pass

    def _likes(self):
        return int(self.base_likes + self.nivel * 900)

    def foto(self):
        """Dibuja la foto aplicando las ediciones; el fondo se deforma alrededor del cuerpo (la pista)."""
        d = self.juego.dibujo
        w, h = 300, 380
        f = pygame.Surface((w, h))
        f.fill((150, 210, 245))
        afinar = self.valores[1]
        for i in range(5):  # baldosas/olas de fondo: se curvan si se afina
            y = 150 + i * 20
            pts = []
            for x in range(0, w + 10, 10):
                curva = -afinar * 18 * max(0, 1 - abs(x - w / 2) / 70)
                pts.append((x, y + curva))
            pygame.draw.lines(f, (60, 150, 210), False, pts, 6)
        pygame.draw.rect(f, (240, 220, 160), (0, 250, w, h - 250))
        pygame.draw.circle(f, (255, 230, 120), (240, 50), 26)
        fig = pygame.Surface((w, h), pygame.SRCALPHA)
        d.personaje(fig, w // 2, h + 20, self.ap, "abajo", 0, False, 3.0, "feliz")
        if afinar > 0:
            nw = int(w * (1 - 0.25 * afinar))
            fig = pygame.transform.smoothscale(fig, (nw, h))
            f.blit(fig, ((w - nw) // 2, 0))
        else:
            f.blit(fig, (0, 0))
        suav = self.valores[0]
        if suav > 0:
            k = max(0.18, 1 - 0.8 * suav)
            peq = pygame.transform.smoothscale(f, (int(w * k), int(h * k)))
            f = pygame.transform.smoothscale(peq, (w, h))
        if self.valores[2] > 0:
            capa = pygame.Surface((w, h), pygame.SRCALPHA)
            capa.fill((255, 180, 200, int(110 * self.valores[2])))
            f.blit(capa, (0, 0))
        return f

    def dibujar_juego(self, sup):
        d, pal = self.juego.dibujo, self.juego.paleta
        sup.fill((22, 18, 36))
        tel = pygame.Rect(90, 40, 340, 470)
        pygame.draw.rect(sup, (15, 15, 22), tel, border_radius=30)
        sup.blit(self.foto(), (tel.x + 20, tel.y + 45))
        d.texto(sup, "Vista previa", (tel.centerx, tel.y + 22), (220, 220, 230), "peq", "center")
        d.texto(sup, "Editor de Algo", (720, 70), pal["algo"], "grande", "center")
        d.algo(sup, 900, 80, self.t, 1.1, 0.4 + self.nivel)
        for i, nombre in enumerate(self.BARRAS):
            b = self._barra(i)
            col = pal["acento"] if i == self.sel else pal["texto"]
            d.texto(sup, nombre, (b.x, b.y - 32), col, "normal")
            pygame.draw.rect(sup, (70, 60, 100), b, border_radius=7)
            pygame.draw.rect(sup, pal["algo"], (b.x, b.y, int(b.w * self.valores[i]), b.h), border_radius=7)
            pygame.draw.circle(sup, (255, 255, 255), (b.x + int(b.w * self.valores[i]), b.centery), 11)
        d.corazon(sup, 580, 445, 11, (235, 70, 110))
        d.texto(sup, f"Algo predice: {self._likes()} me gusta", (600, 432), pal["texto"], "normal")
        boton = pygame.Rect(600, 470, 240, 46)
        d.panel(sup, boton, pal, pal["acento"], 12)
        d.texto(sup, "Publicar (E)", boton.center, pal["texto"], "normal", "center")

    def calcular_resultado(self):
        return {"nivel": self.nivel, "likes": self._likes()}

    def aplicar_efectos(self):
        self.historia.cambiar(autoestima=-int(16 * self.nivel), algo=int(20 * self.nivel))

    def texto_resultado(self):
        n = self.resultado["nivel"]
        if n < 0.1:
            return f"Vale publicó la foto tal como es. {self.resultado['likes']} me gusta. Algo no está contento."
        if n < 0.4:
            return f"Vale editó un poquito. {self.resultado['likes']} me gusta."
        return f"Vale editó bastante. {self.resultado['likes']} me gusta... de una foto que no se parece del todo a ella."
