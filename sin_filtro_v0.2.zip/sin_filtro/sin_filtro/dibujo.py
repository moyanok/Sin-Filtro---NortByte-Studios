"""Dibujo procedural de personajes, Algo, burbujas y texto (sin imágenes externas)."""
import math
import random

import pygame


class Dibujo:
    def __init__(self):
        f = pygame.font.Font
        self.f = {"mini": f(None, 20), "peq": f(None, 24), "normal": f(None, 28),
                  "grande": f(None, 40), "titulo": f(None, 76), "enorme": f(None, 110)}
        self.cursiva = f(None, 28)
        self.cursiva.set_italic(True)
        self._sombra = pygame.Surface((40, 14), pygame.SRCALPHA)
        pygame.draw.ellipse(self._sombra, (0, 0, 0, 70), self._sombra.get_rect())

    # ---------------- texto ----------------
    def texto(self, sup, contenido, pos, color, fuente="normal", ancla="topleft"):
        fnt = self.f[fuente] if isinstance(fuente, str) else fuente
        r = fnt.render(contenido, True, color)
        rect = r.get_rect(**{ancla: pos})
        sup.blit(r, rect)
        return rect

    @staticmethod
    def envolver(fuente, texto, ancho):
        lineas = []
        for parrafo in texto.split("\n"):
            linea = ""
            for palabra in parrafo.split(" "):
                prueba = (linea + " " + palabra).strip()
                if fuente.size(prueba)[0] <= ancho:
                    linea = prueba
                else:
                    if linea:
                        lineas.append(linea)
                    linea = palabra
            lineas.append(linea)
        return lineas

    def parrafo(self, sup, texto, x, y, ancho, color, fuente="normal", inter=4, centrado=False):
        fnt = self.f[fuente] if isinstance(fuente, str) else fuente
        for linea in self.envolver(fnt, texto, ancho):
            r = fnt.render(linea, True, color)
            sup.blit(r, (x + (ancho - r.get_width()) // 2 if centrado else x, y))
            y += fnt.get_height() + inter
        return y

    def panel(self, sup, rect, pal, borde=None, radio=14, alfa=235):
        s = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.rect(s, (*pal["panel"], alfa), s.get_rect(), border_radius=radio)
        sup.blit(s, rect.topleft)
        pygame.draw.rect(sup, borde or pal["borde"], rect, 3, border_radius=radio)

    # ---------------- personajes ----------------
    def personaje(self, sup, x, y, ap, direccion="abajo", t=0.0, caminando=False, s=None, expresion="normal"):
        s = (s or 1.0) * ap.escala * 1.25
        x, y = int(x), int(y)
        if s < 2:
            sup.blit(pygame.transform.smoothscale(self._sombra, (int(30 * s), int(10 * s))), (x - int(15 * s), y - int(5 * s)))
        ancho = [15, 19, 24][ap.contextura] * s
        osc = math.sin(t * 13) * 3 * s if caminando else 0
        # piernas
        for lado, o in ((-1, osc), (1, -osc)):
            alto = 12 * s - max(0, o)
            pygame.draw.rect(sup, ap.pantalon, (x + lado * 4 * s - 3 * s, y - 12 * s - max(0, o) * 0, 6 * s, alto), border_radius=int(2 * s))
            pygame.draw.rect(sup, (40, 36, 44), (x + lado * 4 * s - 3.5 * s, y - 2.5 * s - max(0, o), 7 * s, 3 * s), border_radius=int(2 * s))
        # brazos
        for lado, o in ((-1, -osc), (1, osc)):
            pygame.draw.rect(sup, ap.piel, (x + lado * (ancho / 2 + 1.5 * s) - 2.5 * s, y - 28 * s + o * 0.6, 5 * s, 14 * s), border_radius=int(3 * s))
        # torso
        pygame.draw.rect(sup, ap.ropa, (x - ancho / 2, y - 30 * s, ancho, 19 * s), border_radius=int(5 * s))
        # cabeza
        hy = y - 40 * s
        r = 11 * s
        estilo, pelo = ap.pelo_estilo, ap.pelo_color
        if estilo == "largo" and direccion != "arriba":
            pygame.draw.rect(sup, pelo, (x - 12 * s, hy - 4 * s, 24 * s, 22 * s), border_radius=int(6 * s))
        if estilo == "rizado":
            for ang in range(0, 360, 40):
                a = math.radians(ang)
                pygame.draw.circle(sup, pelo, (x + math.cos(a) * 11 * s, hy + math.sin(a) * 9 * s - 2 * s), 5.5 * s)
        pygame.draw.circle(sup, ap.piel, (x, hy), r)
        if direccion == "arriba":
            pygame.draw.circle(sup, pelo, (x, hy - 1 * s), r + 1 * s)
            if estilo == "largo":
                pygame.draw.rect(sup, pelo, (x - 12 * s, hy, 24 * s, 18 * s), border_radius=int(6 * s))
        else:
            if estilo != "rizado":
                pygame.draw.ellipse(sup, pelo, (x - 12 * s, hy - 13 * s, 24 * s, 13 * s))
            else:
                pygame.draw.ellipse(sup, pelo, (x - 11 * s, hy - 13 * s, 22 * s, 10 * s))
            if estilo == "moño":
                pygame.draw.circle(sup, pelo, (x, hy - 13 * s), 6 * s)
            self._cara(sup, x, hy, s, direccion, expresion)

    def _cara(self, sup, x, hy, s, direccion, expresion):
        ojo = (40, 32, 40)
        if direccion == "abajo":
            ojos = [(x - 4 * s, hy + 1 * s), (x + 4 * s, hy + 1 * s)]
            boca_x = x
        else:
            d = -1 if direccion == "izq" else 1
            ojos = [(x + d * 5 * s, hy + 1 * s)]
            boca_x = x + d * 6 * s
        for o in ojos:
            if expresion == "feliz":
                pygame.draw.arc(sup, ojo, (o[0] - 2 * s, o[1] - 1.5 * s, 4 * s, 3 * s), 0, math.pi, max(1, int(s)))
            else:
                pygame.draw.circle(sup, ojo, o, max(1, 1.7 * s))
        if s >= 2.5:
            mb = (150, 70, 70)
            if expresion == "feliz":
                pygame.draw.arc(sup, mb, (boca_x - 3 * s, hy + 3 * s, 6 * s, 4 * s), math.pi, 2 * math.pi, max(1, int(s * 0.6)))
            elif expresion == "triste":
                pygame.draw.arc(sup, mb, (boca_x - 3 * s, hy + 5 * s, 6 * s, 4 * s), 0, math.pi, max(1, int(s * 0.6)))
            elif expresion == "sorpresa":
                pygame.draw.circle(sup, mb, (boca_x, hy + 6 * s), 1.5 * s)
            else:
                pygame.draw.line(sup, mb, (boca_x - 2 * s, hy + 6 * s), (boca_x + 2 * s, hy + 6 * s), max(1, int(s * 0.6)))
            if direccion == "abajo":
                for bx in (x - 7 * s, x + 7 * s):
                    pygame.draw.circle(sup, (240, 150, 150), (bx, hy + 4 * s), 1.6 * s)

    def algo(self, sup, x, y, t, s=1.0, intensidad=0.5):
        """Algo: el algoritmo personificado. Un celular flotante con un ojo que te sigue."""
        y = y + math.sin(t * 3) * 4 * s
        w, h = 28 * s, 44 * s
        rect = pygame.Rect(0, 0, w, h)
        rect.center = (x, y)
        if random.random() < 0.15 * intensidad + 0.03:
            for col, dx in (((255, 60, 170), -3), ((60, 230, 255), 3)):
                pygame.draw.rect(sup, col, rect.move(dx * s, 0), 2, border_radius=int(6 * s))
        pygame.draw.rect(sup, (25, 20, 40), rect, border_radius=int(6 * s))
        pygame.draw.rect(sup, (255, 70, 170), rect, max(2, int(2 * s)), border_radius=int(6 * s))
        parpadeo = abs(math.sin(t * 0.9)) > 0.97
        ojo = pygame.Rect(0, 0, 20 * s, (3 if parpadeo else 14) * s)
        ojo.center = (x, y - 2 * s)
        pygame.draw.ellipse(sup, (245, 245, 255), ojo)
        if not parpadeo:
            ix = x + math.sin(t * 1.7) * 4 * s
            pygame.draw.circle(sup, (60, 220, 255), (ix, y - 2 * s), 5 * s)
            pygame.draw.circle(sup, (15, 10, 25), (ix, y - 2 * s), 2.5 * s)
        pygame.draw.rect(sup, (255, 70, 170), (x - 5 * s, y + 15 * s, 10 * s, 2 * s))

    def retrato(self, sup, rect, quien, ap, t, expresion="normal", pal=None):
        pygame.draw.rect(sup, (55, 48, 90) if quien != "algo" else (40, 15, 45), rect, border_radius=12)
        clip = sup.get_clip()
        sup.set_clip(rect)
        if quien == "algo":
            self.algo(sup, rect.centerx, rect.centery, t, 2.2, 0.8)
        elif ap is not None:
            s = 3.0
            yp = rect.top + rect.h * 0.42 + 40 * s * 1.25 * ap.escala
            self.personaje(sup, rect.centerx, yp, ap, "abajo", t, False, s, expresion)
        sup.set_clip(clip)
        pygame.draw.rect(sup, pal["borde"] if pal else (255, 255, 255), rect, 3, border_radius=12)

    # ---------------- burbujas ----------------
    def corazon(self, sup, cx, cy, r, color):
        pygame.draw.circle(sup, color, (cx - r * 0.5, cy - r * 0.2), r * 0.55)
        pygame.draw.circle(sup, color, (cx + r * 0.5, cy - r * 0.2), r * 0.55)
        pygame.draw.polygon(sup, color, [(cx - r * 1.02, cy), (cx + r * 1.02, cy), (cx, cy + r * 1.05)])

    def burbuja(self, sup, x, y, tipo, progreso):
        esc = min(1.0, progreso * 5)
        w, h = int(36 * esc), int(30 * esc)
        if w < 4:
            return
        rect = pygame.Rect(0, 0, w, h)
        rect.midbottom = (x, y - 6)
        pygame.draw.rect(sup, (255, 255, 255), rect, border_radius=10)
        pygame.draw.polygon(sup, (255, 255, 255), [(x - 5, rect.bottom - 1), (x + 5, rect.bottom - 1), (x, rect.bottom + 6)])
        if esc < 1:
            return
        if tipo == "corazon":
            self.corazon(sup, rect.centerx, rect.centery - 2, 9, (235, 70, 110))
        else:
            simbolo = {"!": "!", "?": "?", "...": "...", "nota": "~"}.get(tipo, tipo)
            self.texto(sup, simbolo, rect.center, (40, 30, 60), "grande" if tipo != "..." else "normal", "center")
