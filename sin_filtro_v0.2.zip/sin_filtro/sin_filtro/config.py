"""Configuración general y ajustes del jugador."""
ANCHO, ALTO = 960, 540
HUD = 36
FPS = 60
TITULO = "Sin Filtro - NorteByte Studios"

PIELES = [(255, 224, 196), (236, 188, 150), (205, 150, 110), (160, 105, 70), (110, 72, 48)]
ESTILOS_PELO = ["largo", "rizado", "corto", "moño"]
COLORES_PELO = [(40, 28, 24), (95, 60, 35), (200, 150, 80), (150, 60, 40)]
NOMBRES_COLOR_PELO = ["Negro", "Castaño", "Mono", "Cobrizo"]
ROPAS = [(130, 100, 225), (232, 112, 92), (70, 160, 205), (90, 180, 120)]
NOMBRES_ROPA = ["Morado", "Coral", "Azul", "Verde"]
VELOCIDADES_TEXTO = [("Lenta", 22), ("Normal", 45), ("Rápida", 90), ("Instantánea", 9999)]


class Ajustes:
    def __init__(self):
        self.piel = 2
        self.pelo_estilo = 0
        self.pelo_color = 0
        self.contextura = 1
        self.ropa = 0
        self.paleta = 0
        self.velocidad = 1
        self.sonido = True
        self.subtitulos = True

    @property
    def cps(self):
        return VELOCIDADES_TEXTO[self.velocidad][1]
