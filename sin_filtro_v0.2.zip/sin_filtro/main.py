"""Sin Filtro - NorteByte Studios.
Ejecutar:  pip install pygame   y luego   python main.py
"""
from sin_filtro.juego import Juego

if __name__ == "__main__":
    Juego().ejecutar()
