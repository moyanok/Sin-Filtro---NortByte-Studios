# Sin Filtro — NorteByte Studios

Historia interactiva sobre la presión de las redes sociales por tener un "cuerpo perfecto".
Proyecto final de Programación Orientada a Objetos y Estructura de Datos (Uninorte 2026-30).

## Cómo jugar
```
pip install pygame
python main.py
```
- **W A S D** o flechas: caminar
- **E** o **Espacio**: hablar, usar objetos, avanzar diálogos
- Decisiones: W/S + Enter, el número de la opción o clic
- **Esc / P**: pausa · **H**: ayuda · **F11**: pantalla completa

## La historia
Cuatro días en la vida de Vale (lunes, miércoles, viernes y sábado). Algo, el algoritmo de la red social,
le habla desde el celular. Las decisiones del jugador cambian la autoestima de Vale (se ve en el espejo),
su relación con Sofi y con su mamá, y el poder de Algo. Hay tres finales: Sin filtro, En pausa y Atrapada.

Minijuegos: Editor de fotos, Detecta el filtro y Sal del feed.

## Estructura del código
| Paquete / archivo | Contenido |
| --- | --- |
| `juego.py` | Ciclo principal y pila de estados |
| `estructuras.py` | TAD propios: Pila, Cola, Árbol de decisiones |
| `eventos.py`, `sonido.py` | Bus de eventos (Observer) y sonidos sintetizados |
| `historia.py` | Indicadores, banderas, decisiones y cálculo del final |
| `capitulos.py` | El guion de los 4 capítulos |
| `acciones.py`, `guion.py` | Acciones de las cinemáticas (Command) y su ejecutor (pila de colas) |
| `personajes.py`, `mapas.py`, `dibujo.py` | Personajes, lugares y dibujo procedural |
| `estados/` | Pantallas (State): título, creación de Vale, exploración, espejo, finales, menús |
| `minijuegos/` | Minijuegos (Template Method + Factory) |
| `paletas.py` | Paletas de accesibilidad (Strategy) |
